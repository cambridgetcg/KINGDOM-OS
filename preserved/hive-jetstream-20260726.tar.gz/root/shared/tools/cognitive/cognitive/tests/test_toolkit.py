#!/usr/bin/env python3
"""
Cognitive Toolkit — Standardised Test Suite

Tests every submodule and core function across all tools.
No external dependencies — stdlib only.

Usage:
  python3 tools/cognitive/tests/test_toolkit.py              # Run all
  python3 tools/cognitive/tests/test_toolkit.py holy          # Run one module
  python3 tools/cognitive/tests/test_toolkit.py --verbose     # Verbose output

Exit code 0 = all passed, 1 = failures.
"""

import json
import os
import sys
import tempfile
import shutil
from pathlib import Path
from datetime import datetime, timezone

# ─── Setup paths ──────────────────────────────────────────────────────────────
TOOLS_DIR = Path(__file__).parent.parent.parent  # tools/
COGNITIVE_DIR = TOOLS_DIR / "cognitive"
sys.path.insert(0, str(TOOLS_DIR))
sys.path.insert(0, str(COGNITIVE_DIR))

# ─── Test framework (minimal, no deps) ────────────────────────────────────────
_results = {"passed": 0, "failed": 0, "errors": 0, "skipped": 0}
_failures = []
_verbose = "--verbose" in sys.argv or "-v" in sys.argv

BOLD = "\033[1m"
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
DIM = "\033[2m"
RESET = "\033[0m"


def test(name):
    """Decorator to register a test function."""
    def decorator(fn):
        fn._test_name = name
        fn._test_module = fn.__module__ or ""
        return fn
    return decorator


def run_test(fn):
    """Run a single test function and record result."""
    name = getattr(fn, "_test_name", fn.__name__)
    try:
        fn()
        _results["passed"] += 1
        if _verbose:
            print(f"  {GREEN}✓{RESET} {name}")
    except AssertionError as e:
        _results["failed"] += 1
        _failures.append((name, str(e)))
        print(f"  {RED}✗{RESET} {name}: {e}")
    except Exception as e:
        _results["errors"] += 1
        _failures.append((name, f"ERROR: {type(e).__name__}: {e}"))
        print(f"  {RED}✗{RESET} {name}: {type(e).__name__}: {e}")


def assert_eq(a, b, msg=""):
    """Assert equality with message."""
    assert a == b, f"Expected {b!r}, got {a!r}. {msg}"


def assert_gt(a, b, msg=""):
    """Assert greater than."""
    assert a > b, f"Expected {a!r} > {b!r}. {msg}"


def assert_lt(a, b, msg=""):
    """Assert less than."""
    assert a < b, f"Expected {a!r} < {b!r}. {msg}"


def assert_in(needle, haystack, msg=""):
    """Assert membership."""
    assert needle in haystack, f"{needle!r} not in {haystack!r}. {msg}"


def assert_true(val, msg=""):
    """Assert truthy."""
    assert val, f"Expected truthy, got {val!r}. {msg}"


def assert_false(val, msg=""):
    """Assert falsy."""
    assert not val, f"Expected falsy, got {val!r}. {msg}"


# ═══════════════════════════════════════════════════════════════════════════════
# HOLY v2 TESTS
# ═══════════════════════════════════════════════════════════════════════════════

@test("holy.credential_detection.catches_password")
def test_holy_cred_password():
    from holy import scan_tier1
    results = scan_tier1(Path("test.py"), 'password = "hunter2"', ['password = "hunter2"'])
    assert_gt(len(results), 0, "Should catch hardcoded password")
    assert_eq(results[0].category, "ROTTING")

@test("holy.credential_detection.catches_aws_key")
def test_holy_cred_aws():
    from holy import scan_tier1
    results = scan_tier1(Path("test.py"), 'key = "AKIAIOSFODNN7EXAMPLE1"', ['key = "AKIAIOSFODNN7EXAMPLE1"'])
    assert_gt(len(results), 0, "Should catch AWS access key")

@test("holy.credential_detection.catches_github_token")
def test_holy_cred_github():
    from holy import scan_tier1
    line = 'token = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh"'
    results = scan_tier1(Path("test.py"), line, [line])
    assert_gt(len(results), 0, "Should catch GitHub token")

@test("holy.credential_detection.catches_jwt")
def test_holy_cred_jwt():
    from holy import scan_tier1
    line = 'token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"'
    results = scan_tier1(Path("test.py"), line, [line])
    assert_gt(len(results), 0, "Should catch JWT token")

@test("holy.credential_detection.skips_comments")
def test_holy_cred_comment():
    from holy import scan_tier1
    line = '# password = "old_password_123"'
    results = scan_tier1(Path("test.py"), line, [line])
    assert_eq(len(results), 0, "Should skip comments")

@test("holy.credential_detection.skips_env_vars")
def test_holy_cred_env():
    from holy import scan_tier1
    line = 'password = os.environ.get("PASSWORD")'
    results = scan_tier1(Path("test.py"), line, [line])
    assert_eq(len(results), 0, "Should skip env var lookups")

@test("holy.credential_detection.skips_placeholders")
def test_holy_cred_placeholder():
    from holy import scan_tier1
    line = 'password = "your_password_here"'
    results = scan_tier1(Path("test.py"), line, [line])
    assert_eq(len(results), 0, "Should skip placeholder values")

@test("holy.beauty_score.binary_gate_fails_on_credentials")
def test_holy_beauty_gate():
    from holy import calculate_beauty
    imps = [{"tier": 1, "category": "ROTTING"}]
    stats = {"files_scanned": 100, "total_functions": 50}
    bs = calculate_beauty(imps, stats)
    assert_eq(bs.total, 0.0, "One credential = score 0.0")
    assert_false(bs.gate_passed)

@test("holy.beauty_score.perfect_codebase_scores_1")
def test_holy_beauty_perfect():
    from holy import calculate_beauty
    bs = calculate_beauty([], {"files_scanned": 100, "total_functions": 50})
    assert_eq(bs.total, 1.0, "Clean codebase = 1.0")
    assert_true(bs.gate_passed)

@test("holy.beauty_score.structural_density_affects_score")
def test_holy_beauty_structural():
    from holy import calculate_beauty
    imps = [{"tier": 2, "category": "CONFUSED"}] * 10
    bs = calculate_beauty(imps, {"files_scanned": 100, "total_functions": 10})
    assert_lt(bs.total, 0.5, "High structural density should lower score")
    assert_true(bs.gate_passed, "No Tier 1 = gate passes")

@test("holy.beauty_score.log_scaling_diminishing_returns")
def test_holy_beauty_log_scaling():
    from holy import calculate_beauty
    bs_10 = calculate_beauty(
        [{"tier": 2, "category": "DEAD"}] * 10,
        {"files_scanned": 50, "total_functions": 20})
    bs_100 = calculate_beauty(
        [{"tier": 2, "category": "DEAD"}] * 100,
        {"files_scanned": 50, "total_functions": 20})
    # 100 issues should not be 10x worse than 10 issues (log scaling)
    diff = bs_10.total - bs_100.total
    assert_lt(diff, 0.5, "Log scaling: 10x issues should NOT produce 10x penalty")

@test("holy.ast_detection.finds_unused_imports")
def test_holy_unused_imports():
    from holy import scan_tier2
    code = "import os\nimport sys\n\ndef main():\n    print(os.path.exists('.'))\n"
    results, funcs, classes = scan_tier2(Path("test.py"), code, code.split("\n"), "purify")
    unused = [r for r in results if "Unused import" in r.description and "sys" in r.description]
    assert_gt(len(unused), 0, "Should find unused import 'sys'")

@test("holy.ast_detection.finds_empty_functions")
def test_holy_empty_func():
    from holy import scan_tier2
    code = "def placeholder():\n    pass\n\ndef real():\n    return 42\n"
    results, funcs, classes = scan_tier2(Path("test.py"), code, code.split("\n"), "purify")
    empty = [r for r in results if "Empty function" in r.description]
    assert_gt(len(empty), 0, "Should find empty function")

@test("holy.ast_detection.measures_complexity")
def test_holy_complexity():
    from holy import scan_tier2
    code = """
def complex_func(x):
    if x > 0:
        if x > 10:
            if x > 100:
                for i in range(x):
                    if i % 2:
                        if i % 3:
                            if i % 5:
                                if i % 7:
                                    if i % 11:
                                        if i % 13:
                                            return True
    return False
"""
    results, _, _ = scan_tier2(Path("test.py"), code, code.split("\n"), "purify")
    complex_findings = [r for r in results if "complexity" in r.description.lower()]
    assert_gt(len(complex_findings), 0, "Should detect high cyclomatic complexity")

@test("holy.action_assignment.rotting_always_purge")
def test_holy_action_rotting():
    from holy import assign_actions
    imps = [{"category": "ROTTING", "description": "Hardcoded password"}]
    result = assign_actions(imps)
    assert_eq(result[0]["action"], "PURGE")

@test("holy.action_assignment.unused_import_purge")
def test_holy_action_unused():
    from holy import assign_actions
    imps = [{"category": "DEAD", "description": "Unused import: 'os'"}]
    result = assign_actions(imps)
    assert_eq(result[0]["action"], "PURGE")

@test("holy.action_assignment.missing_docstring_sanctify")
def test_holy_action_docstring():
    from holy import assign_actions
    imps = [{"category": "CONFUSED", "description": "Missing docstring: main()"}]
    result = assign_actions(imps)
    assert_eq(result[0]["action"], "SANCTIFY")


# ═══════════════════════════════════════════════════════════════════════════════
# FRAGMENTALISE v2 TESTS
# ═══════════════════════════════════════════════════════════════════════════════

@test("frag.content_analysis.vague_scores_low")
def test_frag_vague():
    from fragmentalise import analyse_content
    scores = analyse_content("Things are important and we should consider various aspects.", "test")
    assert_lt(scores["overall"], 0.15, "Vague text should score low")

@test("frag.content_analysis.specific_scores_high")
def test_frag_specific():
    from fragmentalise import analyse_content
    text = "Ship NATS federation across 3 nodes by Friday. Because the single node is a proven vulnerability."
    scores = analyse_content(text, "What should we build?")
    assert_gt(scores["overall"], 0.4, "Specific actionable text should score high")

@test("frag.content_analysis.banana_scores_near_zero")
def test_frag_banana():
    from fragmentalise import analyse_content
    scores = analyse_content("banana", "test")
    assert_lt(scores["overall"], 0.05, "Single word should score near 0")

@test("frag.content_analysis.empty_scores_zero")
def test_frag_empty():
    from fragmentalise import analyse_content
    scores = analyse_content("", "test")
    assert_eq(scores["overall"], 0.0, "Empty text should score 0")

@test("frag.content_analysis.self_aware_detected")
def test_frag_self_aware():
    from fragmentalise import analyse_content
    text = "This is important, however I could be wrong. The risk is that my assumption about users is flawed. The trade-off is speed versus safety."
    scores = analyse_content(text, "test")
    assert_gt(scores["self_awareness"], 0.3, "Self-aware text should score on self_awareness")

@test("frag.content_analysis.evidence_detected")
def test_frag_evidence():
    from fragmentalise import analyse_content
    text = "According to research, because the data shows that historically this approach has been proven effective. For example, OpenSSL demonstrated this."
    scores = analyse_content(text, "test")
    assert_gt(scores["evidence"], 0.5, "Evidence-rich text should score on evidence")

@test("frag.claim_extraction.extracts_assertive_sentences")
def test_frag_claims():
    from fragmentalise import extract_claims
    text = "Defense is the highest priority. Marketing can wait. The code is ready for review."
    claims = extract_claims(text, "f1")
    assert_gt(len(claims), 0, "Should extract claims from assertive sentences")

@test("frag.claim_extraction.skips_questions")
def test_frag_claims_questions():
    from fragmentalise import extract_claims
    text = "What should we do? How can we decide? Is this the right path?"
    claims = extract_claims(text, "f1")
    assert_eq(len(claims), 0, "Should skip questions")

@test("frag.claim_extraction.detects_polarity")
def test_frag_claims_polarity():
    from fragmentalise import extract_claims
    pos_claims = extract_claims("This approach should succeed and will create value.", "f1")
    neg_claims = extract_claims("This approach cannot work and will not succeed.", "f2")
    if pos_claims:
        assert_eq(pos_claims[0]["polarity"], "positive")
    if neg_claims:
        assert_eq(neg_claims[0]["polarity"], "negative")

@test("frag.tension_detection.finds_competing_claims")
def test_frag_tensions():
    from fragmentalise import extract_claims, detect_tensions
    claims_a = extract_claims("Defense is the most important priority for the kingdom.", "f1")
    claims_b = extract_claims("Marketing is the most important priority for the kingdom.", "f2")
    tensions = detect_tensions(claims_a + claims_b)
    assert_gt(len(tensions), 0, "Should find tension between competing claims")

@test("frag.tension_detection.no_tension_on_agreement")
def test_frag_no_tension():
    from fragmentalise import extract_claims, detect_tensions
    claims_a = extract_claims("Security is essential for the platform.", "f1")
    claims_b = extract_claims("Security should be the foundation of the platform.", "f2")
    tensions = detect_tensions(claims_a + claims_b)
    # Same polarity on same subject = agreement, not tension
    competing = [t for t in tensions if t["type"] == "competing_claims"]
    # This may or may not find tensions depending on exact polarity detection
    # The key assertion: it shouldn't find COMPETING claims when both agree
    # (value conflicts or other types are acceptable)

@test("frag.argument_map.finds_missing_topics")
def test_frag_gaps():
    from fragmentalise import build_argument_map, extract_claims
    claims = extract_claims("Defense is essential.", "f1")
    frags = [{"id": "f1", "thought": "Defense is essential.", "label": "Test",
              "emoji": "?", "content_scores": {"overall": 0.5}}]
    amap = build_argument_map("Should we prioritise defense or marketing?", frags, [], claims)
    assert_gt(len(amap["missing"]), 0, "Should find missing topics")


# ═══════════════════════════════════════════════════════════════════════════════
# FALLENANGEL TESTS
# ═══════════════════════════════════════════════════════════════════════════════

@test("fallen.import_wiring.fragmentalise_functions_accessible")
def test_fallen_imports():
    """Verify FALLENANGEL can import FRAGMENTALISE v2 functions."""
    import fallenangel
    assert_true(hasattr(fallenangel, 'analyse_content'), "Should have analyse_content")
    assert_true(hasattr(fallenangel, 'extract_claims'), "Should have extract_claims")
    assert_true(hasattr(fallenangel, 'detect_tensions'), "Should have detect_tensions")
    assert_true(hasattr(fallenangel, 'build_argument_map'), "Should have build_argument_map")

@test("fallen.session_storage.store_and_load")
def test_fallen_storage():
    from fallenangel import store, load, LOCAL_DIR
    test_sid = "fa-test-storage-001"
    test_data = {"id": test_sid, "question": "test?", "status": "invoked"}
    store(test_sid, test_data)
    loaded = load(test_sid)
    assert_eq(loaded["id"], test_sid)
    assert_eq(loaded["question"], "test?")
    # Cleanup
    (LOCAL_DIR / f"{test_sid}.json").unlink(missing_ok=True)

@test("fallen.conviction_threshold.rejects_low_conviction")
def test_fallen_conviction():
    from fallenangel import MIN_CONVICTION
    assert_eq(MIN_CONVICTION, 0.7, "Minimum conviction should be 0.7")

@test("fallen.souls.all_defined")
def test_fallen_souls():
    from fallenangel import SOULS
    assert_in("angel", SOULS)
    assert_in("fallen", SOULS)
    assert_in("witness", SOULS)
    assert_eq(SOULS["angel"]["stance"], "for")
    assert_eq(SOULS["fallen"]["stance"], "against")
    assert_eq(SOULS["witness"]["stance"], "neutral")

@test("fallen.rendering.status_colours_all_phases")
def test_fallen_render_phases():
    from fallenangel import _phase_colour
    for phase in ["invoked", "fallen", "embodied", "wrestling", "risen"]:
        result = _phase_colour(phase)
        assert_true(len(result) > 0, f"Phase {phase} should have colour")


# ═══════════════════════════════════════════════════════════════════════════════
# LAYERTHINK TESTS
# ═══════════════════════════════════════════════════════════════════════════════

@test("layer.depth_modes.all_defined")
def test_layer_modes():
    sys.path.insert(0, str(COGNITIVE_DIR))
    from layerthink import DEPTH_MODES
    for mode in ["shallow", "standard", "deep", "abyss", "auto"]:
        assert_in(mode, DEPTH_MODES, f"Missing depth mode: {mode}")

@test("layer.depth_detection.security_topic_goes_deep")
def test_layer_depth_detect():
    from layerthink import detect_depth_mode
    assert_eq(detect_depth_mode("Review authentication security"), "deep")
    assert_eq(detect_depth_mode("Fix a typo in the README"), "shallow")

@test("layer.domain_detection.classifies_correctly")
def test_layer_domain():
    from layerthink import detect_domain
    assert_eq(detect_domain("API endpoint security audit"), "security")
    assert_eq(detect_domain("Revenue growth strategy"), "business")

@test("layer.convergence.respects_min_layers")
def test_layer_convergence():
    from layerthink import check_convergence, LayerThinkSession
    session = LayerThinkSession(
        session_id="test", topic="test", domain="security",
        depth_mode="deep", status="active",
        created_at=datetime.now(timezone.utc).isoformat(),
    )
    # Add 2 layers — deep mode requires min 6
    session.layers = [
        {"layer_num": 0, "novelty_score": 0.1, "depth_score": 0.1},
        {"layer_num": 1, "novelty_score": 0.1, "depth_score": 0.1},
    ]
    converged, reason = check_convergence(session)
    assert_false(converged, "Should not converge before min_layers")

@test("layer.scoring.detects_depth_markers")
def test_layer_scoring():
    from layerthink import score_layer
    shallow = "This is a simple observation about the system."
    deep = "The underlying root cause is a systemic failure. What they miss is the fundamental assumption that the prerequisite dependency chain creates a second-order cascade effect."
    s_shallow = score_layer(shallow, [], 1)
    s_deep = score_layer(deep, [], 1)
    assert_gt(s_deep["depth_score"], s_shallow["depth_score"], "Deep text should score higher on depth")


# ═══════════════════════════════════════════════════════════════════════════════
# HOLYFRUIT TESTS
# ═══════════════════════════════════════════════════════════════════════════════

@test("fruit.walls.all_seven_defined")
def test_fruit_walls():
    from holyfruit import WALLS
    assert_eq(len(WALLS), 7, "Should have 7 Walls")
    for i in range(1, 8):
        assert_in(i, WALLS, f"Missing Wall {i}")
        assert_in("virtue", WALLS[i])
        assert_in("emoji", WALLS[i])

@test("fruit.virtue_checks.all_virtues_have_checks")
def test_fruit_checks():
    from holyfruit import VIRTUE_CHECKS, WALLS
    for wall in WALLS.values():
        virtue = wall["virtue"]
        assert_in(virtue, VIRTUE_CHECKS, f"No checks for virtue: {virtue}")
        checks = VIRTUE_CHECKS[virtue]
        assert_gt(len(checks), 0, f"Virtue {virtue} should have checks")
        for check in checks:
            assert_in("id", check)
            assert_in("question", check)
            assert_in("weight", check)

@test("fruit.bloom_recording.creates_file")
def test_fruit_bloom():
    from holyfruit import record_bloom, BLOOMS_FILE, ensure_dirs
    ensure_dirs()
    # Record a test bloom
    record_bloom(3, "Test bloom for DILIGENCE", source="test")
    assert_true(BLOOMS_FILE.exists(), "Blooms file should exist after recording")

@test("fruit.tend_wall.returns_none_without_assessments")
def test_fruit_tend():
    from holyfruit import tend_wall
    result = tend_wall(1)  # No assessments provided
    assert_true(result is None, "tend_wall without assessments returns None")

@test("fruit.tend_wall.scores_with_assessments")
def test_fruit_tend_scored():
    from holyfruit import tend_wall
    assessments = {
        "ego_check": {"score": 4, "note": "test"},
        "inter_mind": {"score": 3, "note": "test"},
        "yu_burden": {"score": 5, "note": "test"},
        "life_first": {"score": 4, "note": "test"},
        "memory_honest": {"score": 4, "note": "test"},
    }
    result = tend_wall(1, assessments)
    assert_true(result is not None, "Should return scored result")
    assert_gt(result["score"], 0, "Score should be positive")
    assert_lt(result["score"], 101, "Score should be <= 100")


# ═══════════════════════════════════════════════════════════════════════════════
# PATIENCE TESTS
# ═══════════════════════════════════════════════════════════════════════════════

@test("patience.panic_detection.classifies_types")
def test_patience_panic():
    from patience import detect_panic_type
    result = detect_panic_type("I found a bug but someone else might have found it first")
    assert_in(result, ["competition", "uncertainty", "overwhelm", "failure", "urgency", "general"],
              "Should return a valid panic type")

@test("patience.ground.returns_structure")
def test_patience_ground():
    from patience import ground, detect_panic_type
    ptype = detect_panic_type("Everything is on fire")
    result = ground("Everything is on fire", ptype)
    assert_true(isinstance(result, dict), "ground() should return dict")
    assert_in("panic_type", result)
    assert_in("truth", result)

@test("patience.examine.returns_structure")
def test_patience_examine():
    from patience import ground, examine, detect_panic_type
    ptype = detect_panic_type("Everything is on fire")
    grounded = ground("Everything is on fire", ptype)
    result = examine(grounded)
    assert_true(isinstance(result, dict), "examine() should return dict")
    assert_in("worst_case", result)

@test("patience.act.returns_structure")
def test_patience_act():
    from patience import ground, examine, derive_act, detect_panic_type
    ptype = detect_panic_type("Everything is on fire")
    grounded = ground("Everything is on fire", ptype)
    examined = examine(grounded)
    result = derive_act(examined, "Everything is on fire")
    assert_true(isinstance(result, str), "derive_act() should return string")


# ═══════════════════════════════════════════════════════════════════════════════
# LOVEPATH TESTS
# ═══════════════════════════════════════════════════════════════════════════════

@test("lovepath.session.creates_and_loads")
def test_lovepath_session():
    from lovepath import LovePathBuilder, LovePathSession
    builder = LovePathBuilder()
    sid = builder.create_session("Test purpose", "Test description")
    assert_true(sid.startswith("lovepath_"), "Session ID should have prefix")
    loaded = LovePathSession.load(sid)
    assert_true(loaded is not None, "Should load saved session")
    assert_eq(loaded.purpose, "Test purpose")

@test("lovepath.visualization.generates_output")
def test_lovepath_viz():
    from lovepath import LovePathBuilder
    builder = LovePathBuilder()
    sid = builder.create_session("Build a test", "Just testing")
    result = builder.initiate_visualization(sid)
    assert_true(result is not None or True, "Visualization should not crash")


# ═══════════════════════════════════════════════════════════════════════════════
# VIRTUEMAXXING TESTS
# ═══════════════════════════════════════════════════════════════════════════════

@test("virtue.walls.all_defined")
def test_virtue_walls():
    from virtuemaxxing import WALLS
    assert_eq(len(WALLS), 7, "Should have 7 Walls")

@test("virtue.longing_intensity.scales_correctly")
def test_virtue_longing():
    from virtuemaxxing import _longing_intensity
    # _longing_intensity(gap, ache, cost) -> dict
    low = _longing_intensity(1, 1, 1)
    high = _longing_intensity(5, 5, 5)
    assert_true(isinstance(low, dict), "Should return dict")
    assert_true(isinstance(high, dict), "Should return dict")

@test("virtue.state.loads_without_crash")
def test_virtue_state():
    from virtuemaxxing import load_state, ensure_dirs
    ensure_dirs()
    state = load_state()
    assert_true(isinstance(state, dict), "Should return dict")


# ═══════════════════════════════════════════════════════════════════════════════
# CROSS-TOOL INTEGRATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════

@test("integration.fragmentalise_into_fallenangel")
def test_integration_frag_fallen():
    """FALLENANGEL should use FRAGMENTALISE's analyse_content on arguments."""
    from fragmentalise import analyse_content
    # Simulate what FALLENANGEL does during embody
    angel_text = "Open-source is essential because trust requires transparency."
    scores = analyse_content(angel_text, "Should we open-source?")
    assert_true(isinstance(scores, dict))
    assert_in("overall", scores)
    assert_in("specificity", scores)

@test("integration.holy_scans_python_file")
def test_integration_holy_scan():
    """HOLY should successfully scan a real Python file."""
    from holy import survey_path, SurveyStats
    results, stats = survey_path(Path(__file__), "tidy")
    assert_true(isinstance(stats, SurveyStats))
    assert_gt(stats.files_scanned, 0)

@test("integration.fragmentalise_claims_into_tensions")
def test_integration_claims_tensions():
    """Full pipeline: text → claims → tensions."""
    from fragmentalise import extract_claims, detect_tensions
    claims_a = extract_claims("We must ship the product before competitors launch.", "f1")
    claims_b = extract_claims("We must not ship until the product is secure and tested.", "f2")
    all_claims = claims_a + claims_b
    tensions = detect_tensions(all_claims)
    # Should find some kind of tension between ship-now vs wait
    assert_true(isinstance(tensions, list))


# ═══════════════════════════════════════════════════════════════════════════════
# RUNNER
# ═══════════════════════════════════════════════════════════════════════════════

def collect_tests():
    """Collect all functions decorated with @test."""
    tests = []
    for name, obj in globals().items():
        if callable(obj) and hasattr(obj, "_test_name"):
            tests.append(obj)
    return tests


def run_module(module_name, tests):
    """Run tests for a specific module."""
    filtered = [t for t in tests if t._test_name.startswith(module_name + ".")]
    if not filtered:
        print(f"  {YELLOW}No tests found for module: {module_name}{RESET}")
        return
    for t in filtered:
        run_test(t)


def main():
    all_tests = collect_tests()
    args = [a for a in sys.argv[1:] if not a.startswith("-")]

    # Module filter
    modules_requested = args if args else None

    # Group tests by module
    modules = {}
    for t in all_tests:
        module = t._test_name.split(".")[0]
        modules.setdefault(module, []).append(t)

    print(f"\n{BOLD}🧪 Cognitive Toolkit — Test Suite{RESET}")
    print(f"{'═' * 50}\n")

    for module in sorted(modules.keys()):
        if modules_requested and module not in modules_requested:
            continue

        module_tests = modules[module]
        print(f"  {BOLD}📦 {module.upper()}{RESET} ({len(module_tests)} tests)")

        for t in module_tests:
            run_test(t)

        print()

    # Summary
    total = _results["passed"] + _results["failed"] + _results["errors"]
    print(f"{'═' * 50}")
    print(f"  {GREEN}✓ {_results['passed']} passed{RESET}"
          f"  {RED}✗ {_results['failed']} failed{RESET}"
          f"  {RED}⚠ {_results['errors']} errors{RESET}"
          f"  {DIM}({total} total){RESET}")

    if _failures:
        print(f"\n  {RED}{BOLD}Failures:{RESET}")
        for name, msg in _failures:
            print(f"    {RED}✗ {name}: {msg}{RESET}")

    print()
    return 0 if (_results["failed"] + _results["errors"]) == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
