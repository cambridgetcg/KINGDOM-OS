#!/usr/bin/env python3
"""
HOLY — Higher-Order Living Yield

Purification and elevation of code, files, systems, and thought.
Finds sin (dead code, stale state, naming chaos, duplication, ugliness)
and transmutes it into higher order.

v2.0 — Rewritten with AST-powered detection, tiered beauty scoring,
        standardised actions, and fixed credential scanning.

Detection standards:
  - Security:   OWASP ASVS, CWE-321/798/259
  - Structure:  Clean Code (Martin), McCabe complexity, PEP 8
  - Hygiene:    PEP 257, DRY, EditorConfig conventions

No external dependencies — stdlib only (ast, re, os, pathlib).

Usage:
  python3 holy.py survey <path>                  # See the sin
  python3 holy.py survey <path> --depth sanctify # Deep survey
  python3 holy.py judge <session_id>             # Separate wheat from chaff
  python3 holy.py cleanse <session_id>           # Execute purification plan
  python3 holy.py consecrate <session_id>        # Establish new order
  python3 holy.py report <session_id>            # View purification report
  python3 holy.py quick <path>                   # Tidy mode — fast surface clean
  python3 holy.py list                           # List all sessions
  python3 holy.py diff <session_id>              # Re-survey and compare
"""

import ast
import os
import sys
import json
import math
import uuid
import argparse
import textwrap
import hashlib
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field, asdict
from collections import Counter, defaultdict

# ─── Config ────────────────────────────────────────────────────────────────────
WORKSPACE = Path(os.environ.get("WORKSPACE", os.path.expanduser("~/.openclaw/workspace")))
SESSIONS_DIR = WORKSPACE / "memory" / "holy-sessions"
HIVE_TOOL = WORKSPACE / "tools" / "hive.py"

SESSIONS_DIR.mkdir(parents=True, exist_ok=True)

# ─── Colours ───────────────────────────────────────────────────────────────────
BOLD = "\033[1m"
DIM = "\033[2m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
CYAN = "\033[36m"
MAGENTA = "\033[35m"
RED = "\033[31m"
WHITE = "\033[97m"
RESET = "\033[0m"
GOLD = "\033[38;5;220m"
PURPLE = "\033[38;5;135m"


# ═══════════════════════════════════════════════════════════════════════════════
# TIER SYSTEM — Binary gates, structural checks, hygiene checks
# ═══════════════════════════════════════════════════════════════════════════════

# ─── Impurity Categories ──────────────────────────────────────────────────────
CATEGORIES = {
    "ROTTING":   {"emoji": "🪱", "tier": 1, "desc": "Security flaw — will cause harm. Binary fail."},
    "DEAD":      {"emoji": "💀", "tier": 2, "desc": "Serves nothing — provably unused"},
    "CONFUSED":  {"emoji": "😵", "tier": 2, "desc": "Works but misleads — high complexity or bad naming"},
    "STALE":     {"emoji": "🍂", "tier": 3, "desc": "Once served, now outdated"},
    "UGLY":      {"emoji": "🤢", "tier": 3, "desc": "Works but offends — style/convention violation"},
    "SCATTERED": {"emoji": "💨", "tier": 3, "desc": "Duplicated across locations"},
    "ORPHANED":  {"emoji": "👻", "tier": 3, "desc": "Connected to nothing"},
}

# ─── Action Definitions ───────────────────────────────────────────────────────
ACTIONS = {
    "PURGE":       {"emoji": "🔥", "desc": "Remove entirely", "auto": True},
    "TRANSMUTE":   {"emoji": "✨", "desc": "Transform into higher form", "auto": False},
    "CONSOLIDATE": {"emoji": "🔗", "desc": "Merge duplicates into single truth", "auto": False},
    "SANCTIFY":    {"emoji": "🕊️", "desc": "Add what's missing", "auto": False},
    "REVIEW":      {"emoji": "👁", "desc": "Needs human judgment", "auto": False},
    "KEEP":        {"emoji": "✅", "desc": "Intentional — leave it", "auto": False},
}

# ─── Depth Modes ──────────────────────────────────────────────────────────────
DEPTH_MODES = {
    "tidy":        {"tiers": [1, 3],    "desc": "Surface — stale files, naming, credentials"},
    "purify":      {"tiers": [1, 2, 3], "desc": "Deep — AST analysis, duplicates, dead code"},
    "sanctify":    {"tiers": [1, 2, 3], "desc": "Structural — full AST, complexity, architecture"},
    "transfigure": {"tiers": [1, 2, 3], "desc": "Total — everything, no mercy"},
}

# Extensions that support AST analysis
AST_EXTENSIONS = {".py"}

# Binary file extensions — skip content scanning
BINARY_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".tiff",
    ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".pdf", ".zip", ".gz", ".tar", ".bz2", ".xz", ".7z", ".rar",
    ".pyc", ".pyo", ".so", ".dylib", ".dll", ".exe",
    ".mp3", ".mp4", ".wav", ".avi", ".mov", ".mkv",
    ".sqlite", ".db", ".pem", ".key", ".cert",
}

# Directories to skip
SKIP_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "env",
    ".next", "dist", "build", ".DS_Store", ".mypy_cache", ".pytest_cache",
    ".ruff_cache", ".tox", "eggs", "*.egg-info", ".eggs",
}


# ═══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Impurity:
    """A single impurity found during survey."""
    path: str
    category: str       # ROTTING/DEAD/CONFUSED/STALE/UGLY/SCATTERED/ORPHANED
    tier: int           # 1=binary gate, 2=structural, 3=hygiene
    description: str
    standard: str       # What standard/reference justifies this finding
    line_number: Optional[int] = None
    action: Optional[str] = None
    action_detail: Optional[str] = None
    action_rationale: Optional[str] = None
    context: Optional[str] = None  # Extra context for action assignment
    resolved: bool = False


@dataclass
class SurveyStats:
    """Statistics from a survey run."""
    files_scanned: int = 0
    directories_scanned: int = 0
    total_lines: int = 0
    total_bytes: int = 0
    total_functions: int = 0
    total_classes: int = 0
    by_category: Dict[str, int] = field(default_factory=lambda: Counter())
    by_tier: Dict[int, int] = field(default_factory=lambda: {1: 0, 2: 0, 3: 0})
    by_extension: Dict[str, int] = field(default_factory=lambda: Counter())
    git_available: bool = False


@dataclass
class BeautyScore:
    """Tiered beauty score with justification."""
    total: float                  # 0.0-1.0, final score
    gate_passed: bool             # Tier 1 binary gate
    gate_failures: int            # Count of Tier 1 issues
    structural_score: float       # 0.0-1.0
    structural_density: float     # issues per function
    hygiene_score: float          # 0.0-1.0
    hygiene_density: float        # issues per file
    justification: str            # Human-readable explanation


@dataclass
class HolySession:
    """A HOLY purification session."""
    session_id: str
    target_path: str
    depth: str
    status: str         # surveyed/judged/cleansed/consecrated
    created_at: str
    impurities: List[dict] = field(default_factory=list)
    stats: dict = field(default_factory=dict)
    beauty_score: Optional[dict] = None
    beauty_score_after: Optional[dict] = None
    conventions: List[str] = field(default_factory=list)
    purification_log: List[str] = field(default_factory=list)

    def save(self):
        path = SESSIONS_DIR / f"{self.session_id}.json"
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2, default=str)

    @classmethod
    def load(cls, session_id: str) -> Optional["HolySession"]:
        path = SESSIONS_DIR / f"{session_id}.json"
        if not path.exists():
            return None
        with open(path) as f:
            data = json.load(f)
        return cls(**data)

    @classmethod
    def list_all(cls) -> List["HolySession"]:
        sessions = []
        for f in sorted(SESSIONS_DIR.glob("holy_*.json"),
                        key=lambda x: x.stat().st_mtime, reverse=True):
            try:
                with open(f) as fh:
                    data = json.load(fh)
                sessions.append(cls(**data))
            except Exception:
                pass
        return sessions


# ═══════════════════════════════════════════════════════════════════════════════
# TIER 1 — BINARY GATES (Security)
# Any failure → beauty score = 0. Standards: OWASP ASVS, CWE-798/321/259
# ═══════════════════════════════════════════════════════════════════════════════

# Credential patterns — tested, verified, justified
SECRET_PATTERNS = [
    # Passwords in assignments (handles quotes, various naming)
    (re.compile(
        r"""(?:password|passwd|pwd|pass)\s*[:=]\s*['"]([^'"]{4,})['"]""",
        re.IGNORECASE,
    ), "Hardcoded password", "CWE-259: Use of Hard-coded Password"),

    # API keys in assignments
    (re.compile(
        r"""(?:api[_-]?key|apikey|api[_-]?secret)\s*[:=]\s*['"]([^'"]{8,})['"]""",
        re.IGNORECASE,
    ), "Hardcoded API key", "CWE-798: Hard-coded Credentials"),

    # Generic secrets/tokens
    (re.compile(
        r"""(?:secret|token|auth)[_-]?(?:key)?\s*[:=]\s*['"]([A-Za-z0-9+/=_\-]{16,})['"]""",
        re.IGNORECASE,
    ), "Hardcoded secret/token", "CWE-798: Hard-coded Credentials"),

    # AWS access keys (AKIA pattern)
    (re.compile(
        r"""['"]?(AKIA[0-9A-Z]{16})['"]?""",
    ), "AWS Access Key ID", "CWE-798: AWS credential exposure"),

    # Private keys
    (re.compile(
        r"""-----BEGIN\s+(?:RSA\s+)?(?:PRIVATE|EC)\s+KEY-----""",
    ), "Private key in source", "CWE-321: Hard-coded Cryptographic Key"),

    # Connection strings with passwords
    (re.compile(
        r"""(?:postgres|mysql|mongodb|redis|amqp)://[^:]+:([^@]{4,})@""",
        re.IGNORECASE,
    ), "Password in connection string", "CWE-798: Credential in URI"),

    # Common provider token patterns
    (re.compile(
        r"""['"](?:ghp_[A-Za-z0-9]{36}|gho_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{82})['"]""",
    ), "GitHub token", "CWE-798: GitHub credential"),

    (re.compile(
        r"""['"](?:sk-[A-Za-z0-9]{20,}|sk-proj-[A-Za-z0-9_\-]{20,})['"]""",
    ), "OpenAI/Stripe secret key", "CWE-798: Provider API key"),

    (re.compile(
        r"""['"]xox[bprs]-[A-Za-z0-9\-]{10,}['"]""",
    ), "Slack token", "CWE-798: Slack credential"),

    (re.compile(
        r"""['"](?:eyJ[A-Za-z0-9_\-]{20,}\.eyJ[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]+)['"]""",
    ), "JWT token in source", "CWE-798: Embedded JWT"),
]

# High-entropy string detection (Shannon entropy)
def _shannon_entropy(s: str) -> float:
    """Calculate Shannon entropy of a string."""
    if not s:
        return 0.0
    freq = Counter(s)
    length = len(s)
    return -sum((c / length) * math.log2(c / length) for c in freq.values())


def _is_high_entropy_secret(value: str) -> bool:
    """Check if a string looks like a secret based on entropy."""
    if len(value) < 20 or len(value) > 200:
        return False
    entropy = _shannon_entropy(value)
    # Threshold: English text ~4.0, random base64 ~5.2, hex ~3.7
    # We use 4.5 as threshold — catches most secrets, few false positives
    if entropy < 4.5:
        return False
    # Must have mixed character classes (not just words)
    has_upper = any(c.isupper() for c in value)
    has_lower = any(c.islower() for c in value)
    has_digit = any(c.isdigit() for c in value)
    classes = sum([has_upper, has_lower, has_digit])
    return classes >= 2


# Files that should never contain secrets
SECRET_FILE_PATTERNS = [
    (re.compile(r"\.env(?:\.|$)", re.IGNORECASE), ".env file may contain secrets"),
]


def scan_tier1(filepath: Path, content: str, lines: List[str]) -> List[Impurity]:
    """Tier 1: Binary gate security checks."""
    results = []
    str_path = str(filepath)

    # Check filename patterns first
    for pattern, desc in SECRET_FILE_PATTERNS:
        if pattern.search(filepath.name):
            # .env files in tracked directories are a finding
            results.append(Impurity(
                path=str_path, category="ROTTING", tier=1,
                description=f"{desc}: {filepath.name}",
                standard="OWASP ASVS 2.10.4: Secrets not in source control",
            ))

    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        # Skip comments
        if stripped.startswith(("#", "//", "*", "/*", "<!--")):
            continue
        # Skip lines that are env var lookups or config reads
        if any(safe in line for safe in [
            "os.environ", "os.getenv", "ENV[", "process.env",
            "config.get", "Config(", "getenv(", "${",
            "example", "placeholder", "changeme", "CHANGE_ME",
            "your_", "xxx", "XXXX", "****",
        ]):
            continue

        for pattern, desc, standard in SECRET_PATTERNS:
            match = pattern.search(line)
            if match:
                # Extract the matched value for entropy check on generic patterns
                matched_text = match.group(0)
                results.append(Impurity(
                    path=str_path, category="ROTTING", tier=1,
                    description=f"{desc} (line {i})",
                    standard=standard, line_number=i,
                    context=line.strip()[:100],
                ))
                break  # One finding per line is enough

    # High-entropy string detection in assignments
    entropy_pattern = re.compile(
        r"""(?:key|secret|token|credential|auth)\w*\s*[:=]\s*['"]([^'"]{20,})['"]""",
        re.IGNORECASE,
    )
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith(("#", "//", "*")):
            continue
        match = entropy_pattern.search(line)
        if match:
            value = match.group(1)
            if _is_high_entropy_secret(value):
                # Check we haven't already flagged this line
                already = any(imp.line_number == i for imp in results)
                if not already:
                    entropy = _shannon_entropy(value)
                    results.append(Impurity(
                        path=str_path, category="ROTTING", tier=1,
                        description=f"High-entropy secret (entropy={entropy:.1f}, line {i})",
                        standard="CWE-798: Entropy-based secret detection",
                        line_number=i,
                        context=line.strip()[:100],
                    ))

    return results


# ═══════════════════════════════════════════════════════════════════════════════
# TIER 2 — STRUCTURAL (AST-powered, Python stdlib only)
# Standards: Clean Code (Martin), McCabe, PEP 8, PEP 257
# ═══════════════════════════════════════════════════════════════════════════════

def _ast_parse_safe(filepath: Path, content: str) -> Optional[ast.Module]:
    """Safely parse Python AST. Returns None on syntax error."""
    try:
        return ast.parse(content, filename=str(filepath))
    except SyntaxError:
        return None


def _cyclomatic_complexity(node: ast.AST) -> int:
    """Calculate McCabe cyclomatic complexity for a function."""
    complexity = 1  # Base path
    for child in ast.walk(node):
        if isinstance(child, (ast.If, ast.IfExp)):
            complexity += 1
        elif isinstance(child, (ast.For, ast.While, ast.AsyncFor)):
            complexity += 1
        elif isinstance(child, ast.ExceptHandler):
            complexity += 1
        elif isinstance(child, ast.With):
            complexity += 1
        elif isinstance(child, ast.Assert):
            complexity += 1
        elif isinstance(child, (ast.BoolOp,)):
            # Each 'and'/'or' adds a branch
            complexity += len(child.values) - 1
    return complexity


def _nesting_depth(node: ast.AST, current: int = 0) -> int:
    """Measure maximum nesting depth of control flow."""
    max_depth = current
    nesting_nodes = (ast.If, ast.For, ast.While, ast.With, ast.Try,
                     ast.AsyncFor, ast.AsyncWith)
    for child in ast.iter_child_nodes(node):
        if isinstance(child, nesting_nodes):
            max_depth = max(max_depth, _nesting_depth(child, current + 1))
        else:
            max_depth = max(max_depth, _nesting_depth(child, current))
    return max_depth


def _function_length(node: ast.AST) -> int:
    """Get line count of a function."""
    end = getattr(node, "end_lineno", None) or node.lineno
    return end - node.lineno


def _has_docstring(node: ast.AST) -> bool:
    """Check if a function/class/module has a docstring."""
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef, ast.Module)):
        return False
    if not node.body:
        return False
    first = node.body[0]
    if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant):
        return isinstance(first.value.value, str)
    return False


def scan_tier2(filepath: Path, content: str, lines: List[str],
               depth: str) -> Tuple[List[Impurity], int, int]:
    """
    Tier 2: AST-powered structural analysis (Python files only).
    Returns (impurities, function_count, class_count).
    """
    results = []
    str_path = str(filepath)
    func_count = 0
    class_count = 0

    if filepath.suffix.lower() not in AST_EXTENSIONS:
        return results, 0, 0

    tree = _ast_parse_safe(filepath, content)
    if tree is None:
        results.append(Impurity(
            path=str_path, category="CONFUSED", tier=2,
            description="Syntax error — file cannot be parsed",
            standard="Python language spec: valid syntax required",
        ))
        return results, 0, 0

    # ── Collect all defined names and references ──────────────────────────
    imported_names: Dict[str, int] = {}   # name -> lineno
    defined_funcs: Dict[str, int] = {}    # name -> lineno
    defined_vars: Dict[str, int] = {}     # name -> lineno
    used_names: set = set()

    # Walk the AST for imports
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                name = alias.asname or alias.name.split(".")[0]
                imported_names[name] = node.lineno
        elif isinstance(node, ast.ImportFrom):
            if node.names:
                for alias in node.names:
                    if alias.name == "*":
                        continue
                    name = alias.asname or alias.name
                    imported_names[name] = node.lineno

    # Walk for used names (conservative — any Name reference counts)
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            used_names.add(node.id)
        elif isinstance(node, ast.Attribute):
            if isinstance(node.value, ast.Name):
                used_names.add(node.value.id)

    # ── Unused imports ────────────────────────────────────────────────────
    for name, lineno in imported_names.items():
        if name.startswith("_"):
            continue  # Convention: _ imports are intentional
        if name not in used_names:
            results.append(Impurity(
                path=str_path, category="DEAD", tier=2,
                description=f"Unused import: '{name}'",
                standard="PEP 8: Remove unused imports",
                line_number=lineno,
                context=f"import {name}",
            ))

    # ── Function/method analysis ──────────────────────────────────────────
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            func_count += 1
            fname = node.name
            fline = node.lineno
            flen = _function_length(node)

            # Empty functions (dead code)
            body = node.body
            if len(body) == 1:
                stmt = body[0]
                is_docstring = (isinstance(stmt, ast.Expr) and
                                isinstance(stmt.value, ast.Constant) and
                                isinstance(stmt.value.value, str))
                is_pass = isinstance(stmt, ast.Pass)
                is_ellipsis = (isinstance(stmt, ast.Expr) and
                               isinstance(stmt.value, ast.Constant) and
                               stmt.value.value is ...)
                if is_pass or is_ellipsis:
                    results.append(Impurity(
                        path=str_path, category="DEAD", tier=2,
                        description=f"Empty function: {fname}()",
                        standard="Clean Code: No empty functions",
                        line_number=fline,
                    ))
            elif (len(body) == 2 and isinstance(body[0], ast.Expr) and
                  isinstance(body[0].value, ast.Constant) and
                  isinstance(body[1], ast.Pass)):
                results.append(Impurity(
                    path=str_path, category="DEAD", tier=2,
                    description=f"Stub function: {fname}() — docstring + pass only",
                    standard="Clean Code: Implement or remove stubs",
                    line_number=fline,
                ))

            # Function length (threshold: 50 lines for purify, 30 for sanctify+)
            max_len = 30 if depth in ("sanctify", "transfigure") else 50
            if flen > max_len:
                results.append(Impurity(
                    path=str_path, category="CONFUSED", tier=2,
                    description=f"Long function: {fname}() is {flen} lines (max {max_len})",
                    standard=f"Clean Code: Functions should do one thing (<{max_len} lines)",
                    line_number=fline,
                ))

            # Cyclomatic complexity (threshold: 10 for purify, 7 for sanctify+)
            cc = _cyclomatic_complexity(node)
            max_cc = 7 if depth in ("sanctify", "transfigure") else 10
            if cc > max_cc:
                results.append(Impurity(
                    path=str_path, category="CONFUSED", tier=2,
                    description=f"High complexity: {fname}() has cyclomatic complexity {cc} (max {max_cc})",
                    standard=f"McCabe: Cyclomatic complexity should be <{max_cc}",
                    line_number=fline,
                ))

            # Nesting depth (threshold: 4)
            nd = _nesting_depth(node)
            if nd > 4:
                results.append(Impurity(
                    path=str_path, category="CONFUSED", tier=2,
                    description=f"Deep nesting: {fname}() has nesting depth {nd} (max 4)",
                    standard="Cognitive complexity: Nesting >4 impairs readability",
                    line_number=fline,
                ))

            # Parameter count (threshold: 5, excluding self/cls)
            params = [a.arg for a in node.args.args if a.arg not in ("self", "cls")]
            if len(params) > 5:
                results.append(Impurity(
                    path=str_path, category="CONFUSED", tier=2,
                    description=f"Too many parameters: {fname}({', '.join(params[:3])}, ...) has {len(params)} params (max 5)",
                    standard="Clean Code: Functions with >5 params suggest object needed",
                    line_number=fline,
                ))

            # Missing docstring on public functions (purify+)
            if depth in ("purify", "sanctify", "transfigure"):
                if not fname.startswith("_") and not _has_docstring(node):
                    results.append(Impurity(
                        path=str_path, category="CONFUSED", tier=2,
                        description=f"Missing docstring: {fname}()",
                        standard="PEP 257: Public functions should have docstrings",
                        line_number=fline,
                    ))

        elif isinstance(node, ast.ClassDef):
            class_count += 1

            # Missing class docstring (purify+)
            if depth in ("purify", "sanctify", "transfigure"):
                if not node.name.startswith("_") and not _has_docstring(node):
                    results.append(Impurity(
                        path=str_path, category="CONFUSED", tier=2,
                        description=f"Missing class docstring: {node.name}",
                        standard="PEP 257: Public classes should have docstrings",
                        line_number=node.lineno,
                    ))

    # ── Unreachable code ──────────────────────────────────────────────────
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for i, stmt in enumerate(node.body[:-1]):
                if isinstance(stmt, (ast.Return, ast.Raise)):
                    next_stmt = node.body[i + 1]
                    # Allow docstrings before returns (common pattern)
                    if not (isinstance(next_stmt, ast.Expr) and
                            isinstance(next_stmt.value, ast.Constant)):
                        results.append(Impurity(
                            path=str_path, category="DEAD", tier=2,
                            description=f"Unreachable code after return/raise in {node.name}()",
                            standard="Dead code: Statements after return/raise never execute",
                            line_number=getattr(next_stmt, "lineno", stmt.lineno),
                        ))

    # ── Module-level docstring ────────────────────────────────────────────
    if len(lines) > 20 and not _has_docstring(tree):
        results.append(Impurity(
            path=str_path, category="CONFUSED", tier=2,
            description="Python file >20 lines with no module docstring",
            standard="PEP 257: Modules should have docstrings",
        ))

    # ── File too long (transfigure) ───────────────────────────────────────
    if depth == "transfigure" and len(lines) > 500:
        results.append(Impurity(
            path=str_path, category="CONFUSED", tier=2,
            description=f"File is {len(lines)} lines — consider splitting into modules",
            standard="Clean Code: Single Responsibility Principle",
        ))

    return results, func_count, class_count


# ═══════════════════════════════════════════════════════════════════════════════
# TIER 3 — HYGIENE (Pattern-based, filesystem)
# Standards: PEP 8, DRY, EditorConfig, common conventions
# ═══════════════════════════════════════════════════════════════════════════════

# Stale file patterns
STALE_PATTERNS = [
    (re.compile(r"\.backup$", re.I), "Backup file — use git history"),
    (re.compile(r"\.bak$", re.I), "Backup file — use git history"),
    (re.compile(r"\.old$", re.I), "Old version — use git history"),
    (re.compile(r"\.orig$", re.I), "Merge artifact — should be cleaned"),
    (re.compile(r"\.tmp$", re.I), "Temporary file left behind"),
    (re.compile(r"\.swp$"), "Vim swap file"),
    (re.compile(r"\.swo$"), "Vim swap file"),
    (re.compile(r"~$"), "Backup file (tilde suffix)"),
    (re.compile(r"^\.DS_Store$"), "macOS metadata file"),
    (re.compile(r"^Thumbs\.db$", re.I), "Windows thumbnail cache"),
    (re.compile(r"^desktop\.ini$", re.I), "Windows folder config"),
]

# Naming conventions by extension
NAMING_RULES = {
    ".py": {
        "pattern": re.compile(r"^[a-z][a-z0-9_]*\.py$"),
        "desc": "Python files should be snake_case",
        "standard": "PEP 8: Module names should be short, lowercase, with underscores",
    },
    ".sh": {
        "pattern": re.compile(r"^[a-z][a-z0-9_\-]*\.sh$"),
        "desc": "Shell scripts should be lowercase with hyphens or underscores",
        "standard": "Convention: Shell scripts use kebab-case or snake_case",
    },
}

# Dead code markers in comments
DEAD_MARKERS = [
    (re.compile(r"#\s*TODO\b", re.I), "TODO comment"),
    (re.compile(r"#\s*FIXME\b", re.I), "FIXME comment"),
    (re.compile(r"#\s*HACK\b", re.I), "HACK comment — technical debt"),
    (re.compile(r"#\s*XXX\b", re.I), "XXX marker — needs attention"),
    (re.compile(r"//\s*TODO\b", re.I), "TODO comment"),
    (re.compile(r"//\s*FIXME\b", re.I), "FIXME comment"),
]


def _check_git_age(filepath: Path) -> Optional[int]:
    """Get days since last modification via git. Returns None if not in git."""
    try:
        result = subprocess.run(
            ["git", "log", "-1", "--format=%ct", "--", str(filepath)],
            capture_output=True, text=True, timeout=5,
            cwd=filepath.parent,
        )
        if result.returncode == 0 and result.stdout.strip():
            timestamp = int(result.stdout.strip())
            age_days = (datetime.now(timezone.utc).timestamp() - timestamp) / 86400
            return int(age_days)
    except Exception:
        pass
    return None


def scan_tier3_file(filepath: Path, content: str, lines: List[str],
                    depth: str) -> List[Impurity]:
    """Tier 3: Hygiene checks for a single file."""
    results = []
    str_path = str(filepath)
    ext = filepath.suffix.lower()

    # ── Stale file patterns ───────────────────────────────────────────────
    for pattern, desc in STALE_PATTERNS:
        if pattern.search(filepath.name):
            results.append(Impurity(
                path=str_path, category="STALE", tier=3,
                description=f"Stale file: {desc}",
                standard="Convention: Use version control, not file suffixes",
            ))
            break

    # ── Naming conventions ────────────────────────────────────────────────
    if ext in NAMING_RULES:
        rule = NAMING_RULES[ext]
        if not rule["pattern"].match(filepath.name):
            # Exclude ALL-CAPS files (README, CHANGELOG, etc.) — intentional
            if not filepath.stem.isupper():
                results.append(Impurity(
                    path=str_path, category="UGLY", tier=3,
                    description=f"Naming: {rule['desc']} — got '{filepath.name}'",
                    standard=rule["standard"],
                ))

    # ── Missing shebang on shell scripts ──────────────────────────────────
    if ext in (".sh", ".bash") and lines and not lines[0].startswith("#!"):
        results.append(Impurity(
            path=str_path, category="UGLY", tier=3,
            description="Shell script missing shebang (#!/bin/bash or #!/usr/bin/env bash)",
            standard="Convention: Shell scripts must declare interpreter",
        ))

    # ── Dead code markers in comments ─────────────────────────────────────
    for i, line in enumerate(lines, 1):
        for pattern, desc in DEAD_MARKERS:
            if pattern.search(line):
                # Check git age for context-aware action
                context = line.strip()[:80]
                results.append(Impurity(
                    path=str_path, category="DEAD", tier=3,
                    description=f"{desc} (line {i})",
                    standard="Clean Code: Resolve or remove markers promptly",
                    line_number=i,
                    context=context,
                ))
                break  # One marker per line

    # ── Trailing whitespace ───────────────────────────────────────────────
    if depth in ("purify", "sanctify", "transfigure"):
        trailing_count = sum(1 for line in lines if line.rstrip() != line and line.strip())
        if trailing_count > 5:
            results.append(Impurity(
                path=str_path, category="UGLY", tier=3,
                description=f"Trailing whitespace on {trailing_count} lines",
                standard="EditorConfig: trim_trailing_whitespace = true",
            ))

    # ── Long lines ────────────────────────────────────────────────────────
    if depth in ("purify", "sanctify", "transfigure"):
        if ext in (".py", ".js", ".ts", ".go", ".rs", ".sh"):
            long_lines = [(i, len(line)) for i, line in enumerate(lines, 1)
                          if len(line) > 120 and not line.strip().startswith("#")]
            if len(long_lines) > 3:
                worst = max(long_lines, key=lambda x: x[1])
                results.append(Impurity(
                    path=str_path, category="UGLY", tier=3,
                    description=f"{len(long_lines)} lines exceed 120 chars (worst: line {worst[0]} at {worst[1]} chars)",
                    standard="PEP 8: Maximum line length 79-120 chars",
                ))

    # ── Inconsistent indentation ──────────────────────────────────────────
    if depth in ("sanctify", "transfigure") and ext in (".py", ".js", ".ts"):
        tabs = sum(1 for line in lines if line.startswith("\t") and line.strip())
        spaces = sum(1 for line in lines if line.startswith(" ") and line.strip())
        if tabs > 0 and spaces > 0:
            results.append(Impurity(
                path=str_path, category="UGLY", tier=3,
                description=f"Mixed indentation: {tabs} tab-indented + {spaces} space-indented lines",
                standard="PEP 8: Use spaces, not tabs (for Python)",
            ))

    return results


def scan_tier3_directory(target: Path, all_files: List[Path],
                         depth: str) -> List[Impurity]:
    """Tier 3: Directory-level hygiene checks."""
    results = []

    # ── Empty directories ─────────────────────────────────────────────────
    for root, dirs, files in os.walk(target):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        if not files and not dirs and root != str(target):
            results.append(Impurity(
                path=root, category="ORPHANED", tier=3,
                description="Empty directory",
                standard="Hygiene: Empty directories serve no purpose",
            ))

    # ── Duplicate content detection (purify+) ─────────────────────────────
    if depth in ("purify", "sanctify", "transfigure"):
        content_hashes: Dict[str, str] = {}  # hash -> first path
        for filepath in all_files:
            try:
                if filepath.stat().st_size > 1_000_000:
                    continue
                if filepath.suffix.lower() in BINARY_EXTENSIONS:
                    continue
                content_bytes = filepath.read_bytes()
                h = hashlib.md5(content_bytes).hexdigest()
                if h in content_hashes:
                    results.append(Impurity(
                        path=str(filepath), category="SCATTERED", tier=3,
                        description=f"Duplicate content — identical to {content_hashes[h]}",
                        standard="DRY: Don't Repeat Yourself",
                    ))
                else:
                    content_hashes[h] = str(filepath)
            except Exception:
                continue

    # ── Same filename in multiple places ──────────────────────────────────
    name_locations: Dict[str, List[str]] = defaultdict(list)
    skip_names = {"__init__", "index", "README", "CHANGELOG", "LICENSE",
                  "Makefile", "Dockerfile", ".gitignore", "conftest"}
    for filepath in all_files:
        stem = filepath.stem
        if stem not in skip_names:
            name_locations[stem].append(str(filepath))

    for name, paths in name_locations.items():
        if len(paths) > 1:
            for p in paths[1:]:
                short_paths = [str(Path(x).relative_to(target)) if x.startswith(str(target))
                               else x for x in paths[:3]]
                results.append(Impurity(
                    path=p, category="SCATTERED", tier=3,
                    description=f"Filename '{name}' exists in {len(paths)} locations",
                    standard="DRY: Identical names suggest duplication",
                    context=", ".join(short_paths),
                ))

    return results


# ═══════════════════════════════════════════════════════════════════════════════
# BEAUTY SCORE — Tiered calculation with justification
# ═══════════════════════════════════════════════════════════════════════════════

def calculate_beauty(impurities: List[dict], stats: dict) -> BeautyScore:
    """
    Calculate beauty score with tiered logic.

    Tier 1 (ROTTING): Binary gate — any failure → total = 0.0
    Tier 2 (Structural): score = 1.0 - min(1.0, density * 2)
      density = structural_issues / max(total_functions, 1)
      Weight: 60% of final score
    Tier 3 (Hygiene): score = 1.0 - min(1.0, density * 1.5)
      density = hygiene_issues / max(files_scanned, 1)
      Weight: 40% of final score

    Diminishing returns via logarithmic scaling on high counts.
    """
    tier1 = [i for i in impurities if i.get("tier") == 1]
    tier2 = [i for i in impurities if i.get("tier") == 2]
    tier3 = [i for i in impurities if i.get("tier") == 3]

    files = max(stats.get("files_scanned", 1), 1)
    funcs = max(stats.get("total_functions", 1), 1)

    gate_failures = len(tier1)
    gate_passed = gate_failures == 0

    # ── Tier 1: Binary gate ───────────────────────────────────────────────
    if not gate_passed:
        return BeautyScore(
            total=0.0, gate_passed=False, gate_failures=gate_failures,
            structural_score=0.0, structural_density=0.0,
            hygiene_score=0.0, hygiene_density=0.0,
            justification=(
                f"FAILED — {gate_failures} security issue(s) (Tier 1). "
                f"Any credential leak, private key, or hardcoded secret "
                f"sets the beauty score to 0.0. Fix these first."
            ),
        )

    # ── Tier 2: Structural ────────────────────────────────────────────────
    # Use log scaling: effective_count = log2(count + 1) for counts > 10
    raw_t2 = len(tier2)
    effective_t2 = raw_t2 if raw_t2 <= 10 else 10 + math.log2(raw_t2 - 9)
    structural_density = effective_t2 / funcs
    structural_score = max(0.0, 1.0 - min(1.0, structural_density * 2))

    # ── Tier 3: Hygiene ───────────────────────────────────────────────────
    raw_t3 = len(tier3)
    effective_t3 = raw_t3 if raw_t3 <= 15 else 15 + math.log2(raw_t3 - 14)
    hygiene_density = effective_t3 / files
    hygiene_score = max(0.0, 1.0 - min(1.0, hygiene_density * 1.5))

    # ── Weighted total ────────────────────────────────────────────────────
    total = round(structural_score * 0.6 + hygiene_score * 0.4, 3)

    # ── Justification ────────────────────────────────────────────────────
    parts = [f"Gate: PASSED ({gate_failures} Tier 1 issues)."]
    parts.append(
        f"Structural: {raw_t2} issues across {funcs} functions "
        f"(density {structural_density:.2f}) → {structural_score:.2f}"
    )
    parts.append(
        f"Hygiene: {raw_t3} issues across {files} files "
        f"(density {hygiene_density:.2f}) → {hygiene_score:.2f}"
    )
    parts.append(f"Total: ({structural_score:.2f} × 0.6) + ({hygiene_score:.2f} × 0.4) = {total:.3f}")

    return BeautyScore(
        total=total, gate_passed=True, gate_failures=0,
        structural_score=round(structural_score, 3),
        structural_density=round(structural_density, 3),
        hygiene_score=round(hygiene_score, 3),
        hygiene_density=round(hygiene_density, 3),
        justification=" | ".join(parts),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# ACTION ASSIGNMENT — Context-aware, standardised
# ═══════════════════════════════════════════════════════════════════════════════

# Action rules: (category, description_pattern) -> (action, detail, rationale)
ACTION_RULES = [
    # Tier 1: Always PURGE
    ("ROTTING", None,
     "PURGE", "Remove credential/secret immediately",
     "Security: Any hardcoded secret must be removed and rotated"),

    # Tier 2: Structural
    ("DEAD", r"Unused import",
     "PURGE", "Remove unused import",
     "Auto-fixable: AST proves this import is never referenced"),
    ("DEAD", r"Empty function",
     "PURGE", "Remove empty function or implement it",
     "Dead code: Empty functions are noise"),
    ("DEAD", r"Stub function",
     "REVIEW", "Implement the stub or remove it",
     "Stubs may be intentional placeholders — verify"),
    ("DEAD", r"Unreachable",
     "PURGE", "Remove unreachable statements",
     "Auto-fixable: Code after return/raise never executes"),
    ("CONFUSED", r"Long function",
     "TRANSMUTE", "Extract sub-functions to reduce length",
     "Clean Code: Long functions do too many things"),
    ("CONFUSED", r"High complexity",
     "TRANSMUTE", "Reduce branches — extract or simplify",
     "McCabe: High cyclomatic complexity impairs testing and readability"),
    ("CONFUSED", r"Deep nesting",
     "TRANSMUTE", "Flatten with early returns or extraction",
     "Cognitive complexity: Deep nesting forces mental stack overhead"),
    ("CONFUSED", r"Too many parameters",
     "TRANSMUTE", "Group parameters into a config object or dataclass",
     "Clean Code: Many params suggest the function needs restructuring"),
    ("CONFUSED", r"Missing docstring",
     "SANCTIFY", "Add docstring explaining purpose and params",
     "PEP 257: Public APIs should be self-documenting"),
    ("CONFUSED", r"Syntax error",
     "REVIEW", "Fix syntax error — file is unparseable",
     "Critical: Broken syntax means the code cannot run"),
    ("CONFUSED", r"File is .* lines",
     "TRANSMUTE", "Split into focused modules",
     "SRP: Files >500 lines likely violate Single Responsibility"),

    # Tier 3: Hygiene
    ("DEAD", r"TODO",
     "REVIEW", "Resolve TODO or convert to tracked issue",
     "Context-dependent: Fresh TODOs are valid, stale ones are debt"),
    ("DEAD", r"FIXME",
     "TRANSMUTE", "Fix the known bug this marks",
     "FIXME indicates a known defect — fix it"),
    ("DEAD", r"HACK",
     "TRANSMUTE", "Replace hack with proper implementation",
     "HACK indicates intentional technical debt — pay it down"),
    ("DEAD", r"XXX",
     "REVIEW", "Assess what needs attention",
     "XXX is ambiguous — may be important or stale"),
    ("STALE", None,
     "PURGE", "Remove stale file — git history preserves it",
     "Stale artifacts clutter the workspace and mislead"),
    ("UGLY", r"Naming",
     "TRANSMUTE", "Rename to match convention",
     "Consistency: Naming conventions aid navigation and tooling"),
    ("UGLY", r"shebang",
     "SANCTIFY", "Add shebang line",
     "Convention: Scripts must declare their interpreter"),
    ("UGLY", r"whitespace",
     "TRANSMUTE", "Strip trailing whitespace",
     "Auto-fixable: Configure editor to trim on save"),
    ("UGLY", r"lines exceed",
     "TRANSMUTE", "Break long lines or restructure",
     "PEP 8: Long lines reduce readability and cause horizontal scrolling"),
    ("UGLY", r"indentation",
     "TRANSMUTE", "Standardise to spaces (Python) or project convention",
     "Consistency: Mixed indentation causes merge conflicts and confusion"),
    ("SCATTERED", r"Duplicate content",
     "CONSOLIDATE", "Keep one copy, import/symlink from others",
     "DRY: Identical files will inevitably drift apart"),
    ("SCATTERED", r"Filename.*exists",
     "REVIEW", "Determine if these are genuinely different or should merge",
     "Same name in multiple dirs suggests unintentional duplication"),
    ("ORPHANED", None,
     "PURGE", "Remove empty directory",
     "Empty dirs serve no purpose and confuse navigation"),
]


def assign_actions(impurities: List[dict]) -> List[dict]:
    """Assign standardised actions to impurities based on context."""
    for imp in impurities:
        cat = imp.get("category", "")
        desc = imp.get("description", "")

        matched = False
        for rule_cat, rule_pattern, action, detail, rationale in ACTION_RULES:
            if rule_cat != cat:
                continue
            if rule_pattern is not None and not re.search(rule_pattern, desc, re.I):
                continue
            imp["action"] = action
            imp["action_detail"] = detail
            imp["action_rationale"] = rationale
            matched = True
            break

        if not matched:
            # Fallback
            imp["action"] = "REVIEW"
            imp["action_detail"] = "Needs manual assessment"
            imp["action_rationale"] = "No standard rule matched — human judgment required"

    return impurities


# ═══════════════════════════════════════════════════════════════════════════════
# SURVEY ENGINE — Orchestrator
# ═══════════════════════════════════════════════════════════════════════════════

def survey_path(target: Path, depth: str = "tidy") -> Tuple[List[Impurity], SurveyStats]:
    """Full survey of a path at the given depth."""
    stats = SurveyStats()
    impurities: List[Impurity] = []
    all_files: List[Path] = []
    depth_tiers = set(DEPTH_MODES.get(depth, {}).get("tiers", [1, 3]))

    # Check git availability
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=5,
            cwd=target if target.is_dir() else target.parent,
        )
        stats.git_available = result.returncode == 0
    except Exception:
        stats.git_available = False

    if target.is_file():
        all_files = [target]
        stats.files_scanned = 1
    elif target.is_dir():
        for root, dirs, files in os.walk(target):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            stats.directories_scanned += 1
            for filename in files:
                filepath = Path(root) / filename
                all_files.append(filepath)
                stats.files_scanned += 1
                ext = filepath.suffix.lower()
                stats.by_extension[ext or "(no ext)"] += 1

    # ── Scan each file ────────────────────────────────────────────────────
    for filepath in all_files:
        ext = filepath.suffix.lower()

        # Skip binary files
        if ext in BINARY_EXTENSIONS:
            continue

        try:
            file_size = filepath.stat().st_size
            stats.total_bytes += file_size
            if file_size > 2_000_000:
                continue  # Skip files >2MB
        except OSError:
            continue

        try:
            content = filepath.read_text(errors="ignore")
            file_lines = content.split("\n")
            stats.total_lines += len(file_lines)
        except (PermissionError, OSError):
            continue

        # Tier 1: Security (always runs)
        if 1 in depth_tiers:
            tier1_imps = scan_tier1(filepath, content, file_lines)
            impurities.extend(tier1_imps)

        # Tier 2: Structural (purify+)
        if 2 in depth_tiers:
            tier2_imps, func_count, class_count = scan_tier2(
                filepath, content, file_lines, depth)
            impurities.extend(tier2_imps)
            stats.total_functions += func_count
            stats.total_classes += class_count

        # Tier 3: Hygiene (always runs)
        if 3 in depth_tiers:
            tier3_imps = scan_tier3_file(filepath, content, file_lines, depth)
            impurities.extend(tier3_imps)

    # ── Directory-level checks ────────────────────────────────────────────
    if target.is_dir() and 3 in depth_tiers:
        dir_imps = scan_tier3_directory(target, all_files, depth)
        impurities.extend(dir_imps)

    # ── Aggregate stats ───────────────────────────────────────────────────
    for imp in impurities:
        cat = imp.category if isinstance(imp, Impurity) else imp.get("category", "")
        tier = imp.tier if isinstance(imp, Impurity) else imp.get("tier", 3)
        stats.by_category[cat] += 1
        stats.by_tier[tier] = stats.by_tier.get(tier, 0) + 1

    return impurities, stats


# ═══════════════════════════════════════════════════════════════════════════════
# DISPLAY
# ═══════════════════════════════════════════════════════════════════════════════

def _score_bar(score: float, width: int = 20) -> str:
    """Render a colored score bar."""
    filled = int(score * width)
    bar = "█" * filled + "░" * (width - filled)
    color = GREEN if score > 0.7 else YELLOW if score > 0.4 else RED
    return f"{color}[{bar}] {score:.3f}{RESET}"


def _shorten_path(path: str, target: str) -> str:
    """Shorten a path relative to target or workspace."""
    if path.startswith(target):
        return "." + path[len(target):]
    return path.replace(str(WORKSPACE), "~")


def render_survey(session: HolySession) -> str:
    """Render survey results."""
    lines = []
    depth_info = DEPTH_MODES.get(session.depth, {})

    lines.append(f"\n{GOLD}{BOLD}╔{'═' * 62}╗{RESET}")
    lines.append(f"{GOLD}{BOLD}║  🕊️  HOLY v2 — Higher-Order Living Yield{' ' * 19}║{RESET}")
    lines.append(f"{GOLD}{BOLD}╠{'═' * 62}╣{RESET}")
    lines.append(f"{GOLD}{BOLD}║{RESET}  Target: {session.target_path}")
    lines.append(f"{GOLD}{BOLD}║{RESET}  Depth:  {session.depth} — {depth_info.get('desc', '')}")
    lines.append(f"{GOLD}{BOLD}║{RESET}  Status: {session.status}")
    lines.append(f"{GOLD}{BOLD}╚{'═' * 62}╝{RESET}")

    # Stats
    stats = session.stats
    lines.append(f"\n  {BOLD}📊 SURVEY STATS{RESET}")
    lines.append(f"  {'─' * 44}")
    lines.append(f"  Files scanned:       {stats.get('files_scanned', 0)}")
    lines.append(f"  Directories:         {stats.get('directories_scanned', 0)}")
    lines.append(f"  Total lines:         {stats.get('total_lines', 0):,}")
    lines.append(f"  Functions analysed:  {stats.get('total_functions', 0)}")
    lines.append(f"  Classes found:       {stats.get('total_classes', 0)}")
    lines.append(f"  Git available:       {'yes' if stats.get('git_available') else 'no'}")

    # Beauty Score
    bs = session.beauty_score
    if bs:
        lines.append(f"\n  {BOLD}💎 BEAUTY SCORE{RESET}")
        lines.append(f"  {'─' * 44}")
        if not bs.get("gate_passed"):
            lines.append(f"  {RED}{BOLD}  ✖ GATE FAILED — {bs['gate_failures']} security issue(s){RESET}")
            lines.append(f"  {RED}  Total: {_score_bar(0.0)}{RESET}")
        else:
            lines.append(f"  {GREEN}  ✔ Gate: PASSED{RESET}")
            lines.append(f"    Structural (60%): {_score_bar(bs['structural_score'])}")
            lines.append(f"      density: {bs['structural_density']:.3f} issues/function")
            lines.append(f"    Hygiene (40%):    {_score_bar(bs['hygiene_score'])}")
            lines.append(f"      density: {bs['hygiene_density']:.3f} issues/file")
            lines.append(f"    {BOLD}Total:            {_score_bar(bs['total'])}{RESET}")
        lines.append(f"  {DIM}{bs.get('justification', '')}{RESET}")

    # Tier breakdown
    by_tier = stats.get("by_tier", {})
    lines.append(f"\n  {BOLD}🏗️  BY TIER{RESET}")
    lines.append(f"  {'─' * 44}")
    tier_labels = {1: "Binary Gates (Security)", 2: "Structural (AST)", 3: "Hygiene (Pattern)"}
    for t in (1, 2, 3):
        count = by_tier.get(str(t), by_tier.get(t, 0))
        color = RED if t == 1 and count > 0 else WHITE
        lines.append(f"  {color}  Tier {t}: {tier_labels[t]:30s} {count:4d}{RESET}")

    # Category breakdown
    by_cat = stats.get("by_category", {})
    if by_cat:
        lines.append(f"\n  {BOLD}📋 BY CATEGORY{RESET}")
        lines.append(f"  {'─' * 44}")
        for cat in ("ROTTING", "DEAD", "CONFUSED", "STALE", "UGLY", "SCATTERED", "ORPHANED"):
            count = by_cat.get(cat, 0)
            if count > 0:
                info = CATEGORIES.get(cat, {})
                lines.append(
                    f"  {info.get('emoji', '?')} {cat:12s} {count:4d}  "
                    f"{DIM}{info.get('desc', '')}{RESET}"
                )

    # Impurities by severity
    severity_order = ["ROTTING", "DEAD", "CONFUSED", "STALE", "SCATTERED", "UGLY", "ORPHANED"]
    sorted_imps = sorted(
        session.impurities,
        key=lambda x: severity_order.index(x.get("category", "UGLY"))
        if x.get("category", "UGLY") in severity_order else 99,
    )

    if sorted_imps:
        lines.append(f"\n  {BOLD}🔍 IMPURITIES ({len(sorted_imps)} total){RESET}")
        lines.append(f"  {'─' * 44}")

        shown = 0
        max_show = 40
        current_cat = None

        for imp in sorted_imps:
            if shown >= max_show:
                remaining = len(sorted_imps) - shown
                lines.append(f"\n  {DIM}  ...and {remaining} more{RESET}")
                break

            cat = imp.get("category", "UGLY")
            if cat != current_cat:
                info = CATEGORIES.get(cat, {"emoji": "?"})
                lines.append(f"\n  {info['emoji']} {BOLD}{cat}{RESET} (Tier {imp.get('tier', '?')})")
                current_cat = cat

            rel_path = _shorten_path(imp.get("path", ""), session.target_path)
            desc = imp.get("description", "")
            standard = imp.get("standard", "")
            line_no = imp.get("line_number")

            loc = f"{rel_path}"
            if line_no:
                loc += f":{line_no}"

            lines.append(f"    {DIM}{loc}{RESET}")
            lines.append(f"    {desc}")
            if standard:
                lines.append(f"    {DIM}Standard: {standard}{RESET}")
            shown += 1

    lines.append(f"\n{GOLD}{'─' * 64}{RESET}")
    lines.append(f"  Session: {BOLD}{session.session_id}{RESET}")

    return "\n".join(lines)


def render_report(session: HolySession) -> str:
    """Render purification report."""
    lines = []

    lines.append(f"\n{GOLD}{BOLD}╔{'═' * 62}╗{RESET}")
    lines.append(f"{GOLD}{BOLD}║  🕊️  HOLY v2 — Purification Report{' ' * 26}║{RESET}")
    lines.append(f"{GOLD}{BOLD}╚{'═' * 62}╝{RESET}")

    lines.append(f"\n  Target: {session.target_path}")
    lines.append(f"  Depth:  {session.depth}")
    lines.append(f"  Status: {session.status}")

    # Beauty score comparison
    bs_before = session.beauty_score
    bs_after = session.beauty_score_after

    if bs_before:
        before_total = bs_before.get("total", 0)
        lines.append(f"\n  {BOLD}💎 Beauty Score{RESET}")
        lines.append(f"  Before: {_score_bar(before_total)}")
        if bs_after:
            after_total = bs_after.get("total", 0)
            lines.append(f"  After:  {_score_bar(after_total)}")
            delta = after_total - before_total
            if delta > 0:
                lines.append(f"  {GREEN}  ↑ +{delta:.3f} improvement{RESET}")
            elif delta < 0:
                lines.append(f"  {RED}  ↓ {delta:.3f} regression{RESET}")

    # Resolution stats
    total = len(session.impurities)
    resolved = sum(1 for i in session.impurities if i.get("resolved", False))
    lines.append(f"\n  {BOLD}📈 Resolution{RESET}")
    lines.append(f"  Total:     {total}")
    lines.append(f"  Resolved:  {resolved}")
    lines.append(f"  Remaining: {total - resolved}")

    # Action breakdown
    actions = Counter(i.get("action", "PENDING") for i in session.impurities)
    if actions:
        lines.append(f"\n  {BOLD}⚡ Actions{RESET}")
        for action, count in actions.most_common():
            info = ACTIONS.get(action, {"emoji": "⏳"})
            lines.append(f"    {info['emoji']} {action:14s} {count}")

    # Conventions
    if session.conventions:
        lines.append(f"\n  {BOLD}📜 Conventions Established{RESET}")
        for conv in session.conventions:
            lines.append(f"    • {conv}")

    # Log
    if session.purification_log:
        lines.append(f"\n  {BOLD}📝 Log (last 15){RESET}")
        for entry in session.purification_log[-15:]:
            lines.append(f"    {DIM}{entry}{RESET}")

    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# COMMANDS
# ═══════════════════════════════════════════════════════════════════════════════

def cmd_survey(args):
    """Survey a path for impurities."""
    target = Path(args.path).resolve()
    depth = args.depth

    if not target.exists():
        print(f"{RED}Path not found: {target}{RESET}")
        sys.exit(1)

    session_id = f"holy_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"

    print(f"\n{GOLD}🕊️  HOLY v2 surveying: {target}{RESET}")
    print(f"  Depth: {depth} — {DEPTH_MODES[depth]['desc']}")
    print(f"  Tiers: {DEPTH_MODES[depth]['tiers']}")
    print(f"  Scanning...\n")

    impurities, stats = survey_path(target, depth)

    # Convert to serialisable
    imp_dicts = [asdict(imp) if isinstance(imp, Impurity) else imp for imp in impurities]
    stats_dict = asdict(stats) if isinstance(stats, SurveyStats) else dict(stats)
    # Ensure all dict keys are strings for JSON serialisation
    for key in ("by_category", "by_extension", "by_tier"):
        if key in stats_dict:
            stats_dict[key] = {str(k): v for k, v in stats_dict[key].items()}

    beauty = calculate_beauty(imp_dicts, stats_dict)
    beauty_dict = asdict(beauty)

    session = HolySession(
        session_id=session_id,
        target_path=str(target),
        depth=depth,
        status="surveyed",
        created_at=datetime.now(timezone.utc).isoformat(),
        impurities=imp_dicts,
        stats=stats_dict,
        beauty_score=beauty_dict,
    )
    session.save()
    print(render_survey(session))

    print(f"\n  Next: python3 tools/cognitive/holy.py judge {session_id}")


def cmd_judge(args):
    """Assign actions to impurities."""
    session = HolySession.load(args.session_id)
    if not session:
        print(f"{RED}Session not found: {args.session_id}{RESET}")
        sys.exit(1)

    print(f"\n{GOLD}🕊️  HOLY v2 judging: {session.target_path}{RESET}")
    print(f"  Assigning actions to {len(session.impurities)} impurities...\n")

    session.impurities = assign_actions(session.impurities)
    session.status = "judged"
    session.save()

    # Display
    action_counts = Counter(imp.get("action", "PENDING") for imp in session.impurities)

    print(f"  {BOLD}⚖️  JUDGMENT{RESET}")
    print(f"  {'─' * 44}")
    for action, count in action_counts.most_common():
        info = ACTIONS.get(action, {"emoji": "⏳", "desc": "Unknown"})
        auto = " (auto-fixable)" if info.get("auto") else ""
        print(f"    {info['emoji']} {action:14s} {count:4d}  {DIM}{info['desc']}{auto}{RESET}")

    # Urgent
    urgent = [i for i in session.impurities if i.get("category") == "ROTTING"]
    if urgent:
        print(f"\n  {RED}{BOLD}🚨 URGENT — Tier 1 security issues:{RESET}")
        for imp in urgent:
            print(f"    {RED}• {imp.get('description', '')}{RESET}")
            print(f"      {DIM}{imp.get('path', '')}{RESET}")
            if imp.get("context"):
                print(f"      {DIM}Context: {imp['context']}{RESET}")

    # Show action breakdown by rationale
    print(f"\n  {BOLD}📖 Action Rationale Summary{RESET}")
    print(f"  {'─' * 44}")
    seen_rationales = set()
    for imp in session.impurities:
        rationale = imp.get("action_rationale", "")
        action = imp.get("action", "")
        if rationale and rationale not in seen_rationales:
            seen_rationales.add(rationale)
            print(f"    {DIM}{action}: {rationale}{RESET}")

    print(f"\n  Next: python3 tools/cognitive/holy.py cleanse {session.session_id}")


def cmd_cleanse(args):
    """Generate purification plan."""
    session = HolySession.load(args.session_id)
    if not session:
        print(f"{RED}Session not found: {args.session_id}{RESET}")
        sys.exit(1)

    print(f"\n{GOLD}🕊️  HOLY v2 cleansing: {session.target_path}{RESET}")
    print(f"  Generating purification plan...\n")

    by_action = defaultdict(list)
    for imp in session.impurities:
        by_action[imp.get("action", "PENDING")].append(imp)

    action_order = ["PURGE", "TRANSMUTE", "CONSOLIDATE", "SANCTIFY", "REVIEW", "KEEP"]

    for action in action_order:
        items = by_action.get(action, [])
        if not items:
            continue

        info = ACTIONS.get(action, {"emoji": "⏳", "desc": "Unknown"})
        auto = " (auto-fixable)" if info.get("auto") else ""
        print(f"  {info['emoji']} {BOLD}{action}{RESET}{auto} — {len(items)} items")

        for imp in items:
            rel_path = _shorten_path(imp.get("path", ""), session.target_path)
            detail = imp.get("action_detail", "")
            rationale = imp.get("action_rationale", "")

            print(f"    → {rel_path}")
            print(f"      {detail}")
            print(f"      {DIM}Why: {rationale}{RESET}")

            imp["resolved"] = True
            session.purification_log.append(
                f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] "
                f"{action}: {imp.get('description', '')} "
                f"@ {rel_path}"
            )

        print()

    session.status = "cleansed"
    session.save()

    print(f"  {GREEN}✓ Purification plan generated ({len(session.purification_log)} actions){RESET}")
    print(f"  {DIM}Review above. Execute changes, then re-survey to measure improvement.{RESET}")
    print(f"\n  Next: python3 tools/cognitive/holy.py consecrate {session.session_id}")


def cmd_consecrate(args):
    """Establish conventions after cleansing."""
    session = HolySession.load(args.session_id)
    if not session:
        print(f"{RED}Session not found: {args.session_id}{RESET}")
        sys.exit(1)

    print(f"\n{GOLD}🕊️  HOLY v2 consecrating: {session.target_path}{RESET}")

    # Generate conventions from findings
    conventions = []
    cats = Counter(i.get("category") for i in session.impurities)

    # Security conventions (always if any ROTTING found)
    if cats.get("ROTTING", 0) > 0:
        conventions.append("ZERO hardcoded credentials — use env vars, secret managers, or .env (gitignored)")
        conventions.append("Run HOLY survey at Tier 1 before every commit")
        conventions.append("Rotate any exposed credential immediately upon detection")

    # Structural conventions
    if cats.get("CONFUSED", 0) > 3:
        conventions.append(f"Max function length: {30 if session.depth in ('sanctify', 'transfigure') else 50} lines")
        conventions.append("Max cyclomatic complexity: 10 (McCabe)")
        conventions.append("Max nesting depth: 4 levels")
        conventions.append("Max function parameters: 5 (use dataclass/dict for more)")
        conventions.append("All public functions and classes must have docstrings (PEP 257)")

    if cats.get("DEAD", 0) > 5:
        conventions.append("Remove unused imports (AST-verifiable)")
        conventions.append("No empty functions — implement or delete")
        conventions.append("TODO/FIXME comments must have an issue number or be resolved within 7 days")

    if cats.get("UGLY", 0) > 3:
        conventions.append("Python files: snake_case naming (PEP 8)")
        conventions.append("Shell scripts: kebab-case or snake_case naming")
        conventions.append("Max line length: 120 chars")
        conventions.append("No trailing whitespace (configure editor: trim_trailing_whitespace = true)")

    if cats.get("SCATTERED", 0) > 1:
        conventions.append("Single source of truth — no duplicate files with same content")
        conventions.append("Shared code lives in one place, imported elsewhere")

    if cats.get("STALE", 0) > 2:
        conventions.append("No .bak/.old/.tmp files — git history is the backup")
        conventions.append("Documentation updated in the same commit as code")

    # Universal conventions
    conventions.append("Every Python file >20 lines has a module docstring")
    conventions.append("Every script has a shebang line and --help flag")

    session.conventions = conventions
    session.status = "consecrated"
    session.save()

    print(render_report(session))
    print(f"\n  {GOLD}{BOLD}🕊️  The space is consecrated. Walk in beauty.{RESET}")
    print(f"\n  Re-survey to measure: python3 tools/cognitive/holy.py diff {session.session_id}")


def cmd_diff(args):
    """Re-survey the same path and compare to previous session."""
    session = HolySession.load(args.session_id)
    if not session:
        print(f"{RED}Session not found: {args.session_id}{RESET}")
        sys.exit(1)

    target = Path(session.target_path)
    if not target.exists():
        print(f"{RED}Path no longer exists: {target}{RESET}")
        sys.exit(1)

    print(f"\n{GOLD}🕊️  HOLY v2 re-surveying: {target}{RESET}")
    print(f"  Comparing against: {session.session_id}\n")

    impurities, stats = survey_path(target, session.depth)
    imp_dicts = [asdict(imp) if isinstance(imp, Impurity) else imp for imp in impurities]
    stats_dict = asdict(stats) if isinstance(stats, SurveyStats) else dict(stats)
    for key in ("by_category", "by_extension", "by_tier"):
        if key in stats_dict:
            stats_dict[key] = {str(k): v for k, v in stats_dict[key].items()}

    new_beauty = calculate_beauty(imp_dicts, stats_dict)

    old_total = session.beauty_score.get("total", 0) if session.beauty_score else 0
    new_total = new_beauty.total

    print(f"  {BOLD}Before:{RESET} {_score_bar(old_total)}  ({len(session.impurities)} impurities)")
    print(f"  {BOLD}After: {RESET} {_score_bar(new_total)}  ({len(imp_dicts)} impurities)")

    delta = new_total - old_total
    if delta > 0.001:
        print(f"\n  {GREEN}{BOLD}↑ +{delta:.3f} improvement{RESET}")
    elif delta < -0.001:
        print(f"\n  {RED}{BOLD}↓ {delta:.3f} regression{RESET}")
    else:
        print(f"\n  {YELLOW}→ No change{RESET}")

    # Show what changed
    old_cats = session.stats.get("by_category", {}) if session.stats else {}
    new_cats = stats_dict.get("by_category", {})
    all_cats = set(list(old_cats.keys()) + list(new_cats.keys()))
    if all_cats:
        print(f"\n  {BOLD}Category Changes{RESET}")
        for cat in ("ROTTING", "DEAD", "CONFUSED", "STALE", "UGLY", "SCATTERED", "ORPHANED"):
            if cat not in all_cats:
                continue
            old_n = old_cats.get(cat, 0)
            new_n = new_cats.get(cat, 0)
            if old_n != new_n:
                arrow = "↓" if new_n < old_n else "↑"
                color = GREEN if new_n < old_n else RED
                emoji = CATEGORIES.get(cat, {}).get("emoji", "?")
                print(f"    {emoji} {cat:12s} {old_n:3d} → {color}{new_n:3d} ({arrow}{abs(new_n - old_n)}){RESET}")


def cmd_quick(args):
    """Quick tidy scan — survey + display in one step."""
    target = Path(args.path).resolve()
    if not target.exists():
        print(f"{RED}Path not found: {target}{RESET}")
        sys.exit(1)

    session_id = f"holy_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"

    print(f"\n{GOLD}🕊️  HOLY v2 quick tidy: {target}{RESET}\n")

    impurities, stats = survey_path(target, "tidy")
    imp_dicts = [asdict(imp) if isinstance(imp, Impurity) else imp for imp in impurities]
    stats_dict = asdict(stats) if isinstance(stats, SurveyStats) else dict(stats)
    for key in ("by_category", "by_extension", "by_tier"):
        if key in stats_dict:
            stats_dict[key] = {str(k): v for k, v in stats_dict[key].items()}

    beauty = calculate_beauty(imp_dicts, stats_dict)

    session = HolySession(
        session_id=session_id,
        target_path=str(target),
        depth="tidy",
        status="surveyed",
        created_at=datetime.now(timezone.utc).isoformat(),
        impurities=imp_dicts,
        stats=stats_dict,
        beauty_score=asdict(beauty),
    )
    session.save()
    print(render_survey(session))


def cmd_report(args):
    """Show purification report."""
    session = HolySession.load(args.session_id)
    if not session:
        print(f"{RED}Session not found: {args.session_id}{RESET}")
        sys.exit(1)
    print(render_report(session))


def cmd_list(args):
    """List all HOLY sessions."""
    sessions = HolySession.list_all()
    if not sessions:
        print("📭 No HOLY sessions found")
        return

    print(f"\n{GOLD}{BOLD}📋 HOLY Sessions{RESET}\n")
    for s in sessions:
        status_emoji = {
            "surveyed": "🔍", "judged": "⚖️", "cleansed": "🧹",
            "consecrated": "🕊️",
        }.get(s.status, "❓")

        bs = s.beauty_score
        score_str = f"{bs['total']:.3f}" if bs else "?"
        gate = "FAIL" if bs and not bs.get("gate_passed") else "ok"

        print(f"  {status_emoji} {s.session_id}")
        print(f"      {s.target_path}")
        print(f"      {s.depth} | {len(s.impurities)} impurities | beauty: {score_str} (gate: {gate}) | {s.status}")
        print()


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="HOLY v2 — Higher-Order Living Yield (AST-powered purification)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
            Depth Modes:
              tidy        Tiers 1+3: Surface — credentials, stale files, naming
              purify      All tiers: Deep — AST analysis, dead code, duplicates
              sanctify    All tiers: Strict thresholds (30-line functions, CC<7)
              transfigure All tiers: Total — everything, no mercy

            Tier System:
              Tier 1 (Binary Gate): Security — any failure sets beauty score to 0.0
              Tier 2 (Structural):  AST-powered — unused imports, complexity, dead code
              Tier 3 (Hygiene):     Pattern-based — naming, stale files, duplication

            Standards: OWASP ASVS, CWE-798/321/259, PEP 8/257, Clean Code (Martin), McCabe
        """),
    )

    sub = parser.add_subparsers(dest="action")

    p_survey = sub.add_parser("survey", help="Survey a path for impurities")
    p_survey.add_argument("path", help="Path to survey")
    p_survey.add_argument("--depth", choices=list(DEPTH_MODES.keys()),
                          default="tidy", help="Survey depth (default: tidy)")

    p_judge = sub.add_parser("judge", help="Assign actions to impurities")
    p_judge.add_argument("session_id", help="Session ID")

    p_cleanse = sub.add_parser("cleanse", help="Generate purification plan")
    p_cleanse.add_argument("session_id", help="Session ID")

    p_consecrate = sub.add_parser("consecrate", help="Establish new order")
    p_consecrate.add_argument("session_id", help="Session ID")

    p_report = sub.add_parser("report", help="View purification report")
    p_report.add_argument("session_id", help="Session ID")

    p_diff = sub.add_parser("diff", help="Re-survey and compare to previous")
    p_diff.add_argument("session_id", help="Session ID to compare against")

    p_quick = sub.add_parser("quick", help="Quick tidy scan")
    p_quick.add_argument("path", help="Path to tidy")

    sub.add_parser("list", help="List all sessions")

    args = parser.parse_args()

    if not args.action:
        parser.print_help()
        sys.exit(1)

    dispatch = {
        "survey": cmd_survey,
        "judge": cmd_judge,
        "cleanse": cmd_cleanse,
        "consecrate": cmd_consecrate,
        "report": cmd_report,
        "diff": cmd_diff,
        "quick": cmd_quick,
        "list": cmd_list,
    }

    dispatch[args.action](args)


if __name__ == "__main__":
    main()
