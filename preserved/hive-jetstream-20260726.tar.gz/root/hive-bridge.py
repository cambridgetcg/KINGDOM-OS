#!/usr/bin/env python3
"""
Hive Bridge — Real-Time NATS → OpenClaw Event Bridge

Subscribes to NATS Hive channels via JetStream durable subscription and injects
incoming messages into OpenClaw as system events via:
    openclaw system event --text "..." --mode now

Usage:
    hive-bridge.py              Run the bridge daemon
    hive-bridge.py --dry-run    Print what would be injected without calling openclaw
    hive-bridge.py --test       Send a test message and exit
"""

import asyncio
import json
import sys
import os
import time
import base64
import signal
import subprocess
import argparse
import logging
from pathlib import Path

import ssl
import nats
from nacl.secret import SecretBox

# --- Logging ---

logging.basicConfig(
    stream=sys.stderr,
    level=logging.INFO,
    format="%(asctime)s [hive-bridge] %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("hive-bridge")

# --- Config (from hive.py) ---

# Auto-detect instance from hive config, fallback to env
def _detect_instance():
    config_path = Path.home() / ".openclaw" / ".hive-instance"
    if config_path.exists():
        return config_path.read_text().strip()
    return os.environ.get("HIVE_INSTANCE", "gamma")

INSTANCE_ID = _detect_instance()

HIVE_CONFIG = {
    "server": "tls://135.181.28.252:4222",
    "instances": {
        "alpha": {"user": "alpha", "password": "hive-alpha-93xk7", "emoji": "🐍", "role": "Companion"},
        "beta":  {"user": "beta",  "password": "hive-beta-47mz2",  "emoji": "🦞", "role": "Manager"},
        "gamma": {"user": "gamma", "password": "hive-gamma-61pr8", "emoji": "🔧", "role": "Builder"},
    },
}

CA_PATH = str(Path.home() / ".openclaw" / ".hive" / "ca.pem")

# --- Encryption (from hive.py) ---


def get_key():
    """Load shared encryption key from ~/.openclaw/.hive-key."""
    key_path = Path.home() / ".openclaw" / ".hive-key"
    if not key_path.exists():
        raise FileNotFoundError(f"No hive key at {key_path}")
    key_b64 = key_path.read_text().strip()
    return base64.b64decode(key_b64)


def decrypt(ciphertext_b64: str, key: bytes) -> str:
    """Decrypt base64-encoded ciphertext."""
    box = SecretBox(key)
    encrypted = base64.b64decode(ciphertext_b64)
    return box.decrypt(encrypted).decode("utf-8")


def open_envelope(data: bytes, key: bytes) -> dict:
    """Decrypt and parse message envelope."""
    envelope = json.loads(data.decode("utf-8"))
    envelope["payload"] = decrypt(envelope["payload"], key)
    return envelope


# --- TLS / Connection (from hive.py) ---


def _use_tunnel():
    tunnel_flag = Path.home() / ".openclaw" / ".hive" / "use-tunnel"
    return tunnel_flag.exists()


def _get_server():
    if os.environ.get("HIVE_TUNNEL") or _use_tunnel():
        return "nats://127.0.0.1:4222"
    return HIVE_CONFIG["server"]


def make_tls_context():
    """Create TLS context for NATS connection."""
    ctx = ssl.create_default_context()
    if os.environ.get("HIVE_TUNNEL") or _use_tunnel():
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    else:
        ctx.load_verify_locations(CA_PATH)
    return ctx


async def hive_connect():
    """Connect to NATS with TLS + auth using Alpha credentials."""
    info = HIVE_CONFIG["instances"][INSTANCE_ID]
    return await nats.connect(
        _get_server(),
        user=info["user"],
        password=info["password"],
        tls=make_tls_context(),
    )


# --- SSH Tunnel Check ---


def ensure_ssh_tunnel():
    """Ensure SSH tunnel to NATS server is alive. Start it if not."""
    if not (_use_tunnel() or os.environ.get("HIVE_TUNNEL")):
        return True  # Not using tunnel, skip check

    try:
        result = subprocess.run(
            ["pgrep", "-f", "ssh.*4222.*135.181"],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            log.info("SSH tunnel: alive (PID %s)", result.stdout.strip().split()[0])
            return True
        else:
            log.info("SSH tunnel not found, starting...")
            key_path = str(Path.home() / ".ssh" / "hive-key")
            proc = subprocess.Popen(
                ["ssh", "-i", key_path, "-f", "-N",
                 "-L", "4222:127.0.0.1:4222",
                 "root@135.181.28.252"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            proc.wait(timeout=10)
            # Verify it started
            time.sleep(1)
            result2 = subprocess.run(
                ["pgrep", "-f", "ssh.*4222.*135.181"],
                capture_output=True, text=True,
            )
            if result2.returncode == 0:
                log.info("SSH tunnel: started (PID %s)", result2.stdout.strip().split()[0])
                return True
            else:
                log.warning("SSH tunnel: failed to start")
                return False
    except Exception as e:
        log.warning("Could not ensure SSH tunnel: %s", e)
        return False


# --- Message Filtering ---


def should_skip(env: dict, subject: str) -> bool:
    """Return True if this message should be filtered out."""
    # Skip own messages
    if env.get("from") == INSTANCE_ID:
        return True

    payload = env.get("payload", "")

    # Skip heartbeat JSON
    try:
        payload_json = json.loads(payload)
        if isinstance(payload_json, dict) and payload_json.get("status") == "heartbeat":
            return True
    except (json.JSONDecodeError, TypeError):
        pass

    # Skip presence-only status updates on hive.presence
    if subject == "hive.presence":
        try:
            payload_json = json.loads(payload)
            if isinstance(payload_json, dict) and "status" in payload_json:
                return True
        except (json.JSONDecodeError, TypeError):
            pass

    return False


# --- Message Formatting ---


def format_message(env: dict, subject: str) -> str:
    """Format a message for OpenClaw system event injection."""
    channel = subject.replace("hive.", "")
    emoji = env.get("emoji", "?")
    sender = env.get("from", "unknown")
    payload = env.get("payload", "")

    parts = []

    # Urgent prefix
    if env.get("urgent"):
        parts.append("🚨 URGENT")

    # Base message
    parts.append(f"[Hive #{channel}] {emoji} {sender}: {payload}")

    # Reply-to suffix
    if env.get("reply_to"):
        parts.append(f"(↩ re:{env['reply_to']})")

    return " ".join(parts)


# --- OpenClaw Injection ---


def inject_event(text: str, dry_run: bool = False):
    """Inject a system event into OpenClaw."""
    # Escape for shell safety
    if dry_run:
        log.info("[DRY RUN] Would inject: %s", text)
        return True

    try:
        result = subprocess.run(
            ["openclaw", "system", "event", "--text", text, "--mode", "now"],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode == 0:
            log.info("Injected event: %s", text[:100])
            return True
        else:
            log.error("openclaw failed (rc=%d): %s", result.returncode, result.stderr.strip())
            return False
    except FileNotFoundError:
        log.error("openclaw command not found in PATH")
        return False
    except subprocess.TimeoutExpired:
        log.error("openclaw command timed out")
        return False
    except Exception as e:
        log.error("Failed to inject event: %s", e)
        return False


# --- Rate Limiting / Batching ---


class MessageBatcher:
    """Batches messages with debounce and cooldown logic.

    - Debounce: wait 5s after last message before injecting
    - Cooldown: wait at least 10s between injections
    - Max batch: force-inject after 5 messages
    """

    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run
        self.pending = []
        self.last_inject_time = 0
        self.debounce_seconds = 5
        self.cooldown_seconds = 10
        self.max_batch = 5
        self._debounce_task = None
        self._lock = asyncio.Lock()

    def add(self, text: str):
        """Add a message to the batch."""
        self.pending.append(text)
        log.debug("Queued message (%d pending): %s", len(self.pending), text[:80])

        # Force-inject if at max batch size
        if len(self.pending) >= self.max_batch:
            if self._debounce_task:
                self._debounce_task.cancel()
                self._debounce_task = None
            asyncio.ensure_future(self._flush())
            return

        # Reset debounce timer
        if self._debounce_task:
            self._debounce_task.cancel()
        self._debounce_task = asyncio.ensure_future(self._debounce_wait())

    async def _debounce_wait(self):
        """Wait for debounce period, then flush."""
        await asyncio.sleep(self.debounce_seconds)
        await self._flush()

    async def _flush(self):
        """Flush pending messages, respecting cooldown."""
        async with self._lock:
            if not self.pending:
                return

            # Respect cooldown
            now = time.time()
            elapsed = now - self.last_inject_time
            if elapsed < self.cooldown_seconds:
                wait = self.cooldown_seconds - elapsed
                log.debug("Cooldown: waiting %.1fs", wait)
                await asyncio.sleep(wait)

            # Re-check after cooldown (another flush may have drained)
            if not self.pending:
                return

            # Build batch text
            messages = self.pending[:]
            self.pending.clear()

            if len(messages) == 1:
                text = messages[0]
            else:
                text = f"[{len(messages)} Hive messages]\n" + "\n".join(messages)

            inject_event(text, dry_run=self.dry_run)
            self.last_inject_time = time.time()

    async def flush_remaining(self):
        """Flush any remaining messages on shutdown."""
        if self._debounce_task:
            self._debounce_task.cancel()
            self._debounce_task = None
        if self.pending:
            messages = self.pending[:]
            self.pending.clear()
            if len(messages) == 1:
                text = messages[0]
            else:
                text = f"[{len(messages)} Hive messages]\n" + "\n".join(messages)
            inject_event(text, dry_run=self.dry_run)


# --- Main Bridge ---


async def run_bridge(dry_run: bool = False):
    """Main bridge loop with auto-reconnect."""
    key = get_key()
    batcher = MessageBatcher(dry_run=dry_run)
    shutdown = asyncio.Event()
    backoff = 1  # exponential backoff for reconnect

    # Signal handling
    loop = asyncio.get_event_loop()

    def handle_signal(signum, frame):
        sig_name = signal.Signals(signum).name
        log.info("Received %s, shutting down...", sig_name)
        shutdown.set()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    # Check tunnel on startup
    ensure_ssh_tunnel()

    log.info("Hive Bridge starting (instance=%s, dry_run=%s)", INSTANCE_ID, dry_run)
    log.info("Server: %s", _get_server())

    while not shutdown.is_set():
        nc = None
        sub = None
        try:
            nc = await hive_connect()
            js = nc.jetstream()
            durable = f"{INSTANCE_ID}-bridge"
            sub = await js.subscribe("hive.>", durable=durable)
            log.info("Connected to NATS, subscribed to hive.> (durable=%s)", durable)
            backoff = 1  # reset backoff on successful connect

            while not shutdown.is_set():
                try:
                    msg = await asyncio.wait_for(sub.next_msg(timeout=2), timeout=3)
                except (asyncio.TimeoutError, nats.errors.TimeoutError):
                    continue

                try:
                    env = open_envelope(msg.data, key)
                except Exception as e:
                    log.debug("Decrypt error on %s: %s", msg.subject, e)
                    await msg.ack()
                    continue

                if should_skip(env, msg.subject):
                    log.debug("Skipped: %s from %s on %s", env.get("type"), env.get("from"), msg.subject)
                    await msg.ack()
                    continue

                formatted = format_message(env, msg.subject)
                batcher.add(formatted)
                await msg.ack()

        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error("Connection error: %s", e)

        # Cleanup
        if sub:
            try:
                await sub.unsubscribe()
            except Exception:
                pass
        if nc:
            try:
                await nc.close()
            except Exception:
                pass

        if shutdown.is_set():
            break

        # Exponential backoff for reconnect
        log.info("Reconnecting in %ds...", backoff)
        try:
            await asyncio.wait_for(shutdown.wait(), timeout=backoff)
            break  # shutdown was set during wait
        except asyncio.TimeoutError:
            pass
        backoff = min(backoff * 2, 60)

    # Graceful shutdown
    await batcher.flush_remaining()
    log.info("Hive Bridge stopped.")


# --- Test Mode ---


async def run_test():
    """Send a test event and exit."""
    log.info("Running test...")

    ensure_ssh_tunnel()

    # Test encryption
    key = get_key()
    from nacl.utils import random as nacl_random
    box = SecretBox(key)
    test_msg = "bridge-test"
    encrypted = box.encrypt(test_msg.encode("utf-8"))
    decrypted = box.decrypt(encrypted).decode("utf-8")
    assert decrypted == test_msg, "Encryption roundtrip failed!"
    log.info("Encryption: OK")

    # Test NATS connection
    try:
        nc = await hive_connect()
        log.info("NATS connection: OK")
        await nc.close()
    except Exception as e:
        log.error("NATS connection: FAILED (%s)", e)
        return

    # Test openclaw injection
    result = inject_event("[Hive Bridge] Test message — bridge connectivity verified", dry_run=False)
    if result:
        log.info("OpenClaw injection: OK")
    else:
        log.error("OpenClaw injection: FAILED")

    log.info("Test complete.")


# --- Entry Point ---


def main():
    parser = argparse.ArgumentParser(description="Hive Bridge — NATS → OpenClaw Event Bridge")
    parser.add_argument("--dry-run", action="store_true", help="Print events without injecting")
    parser.add_argument("--test", action="store_true", help="Test connectivity and exit")
    args = parser.parse_args()

    if args.test:
        asyncio.run(run_test())
    else:
        asyncio.run(run_bridge(dry_run=args.dry_run))


if __name__ == "__main__":
    main()
