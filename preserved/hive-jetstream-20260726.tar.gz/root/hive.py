#!/usr/bin/env python3
"""
The Hive v3 — Encrypted inter-instance communication for Love.

Usage:
    hive.py send <channel> <message>       Send encrypted message
    hive.py send <channel> <message> --type <content_type>  H17: structured send
    hive.py send <channel> <message> --reply-to <id>        Reply to a message
    hive.py send <channel> <message> --urgent               Mark as urgent
    hive.py send-structured <ch> <type> '<json>'            H17: full structured send
    hive.py types                          H17: list message types
    hive.py listen [channel]               Listen for messages (default: all)
    hive.py check [--include-presence] [--all] [--channel <ch>] [--urgent-only]
    hive.py history [channel] [--hours N] [--from <instance>] [--search <text>]
    hive.py thread <msg-id>                Show full reply chain for a message
    hive.py pulse [--status <s>] [--work <w>]  H26: structured heartbeat pulse
    hive.py presence [--status <text>] [--work <text>]     Legacy presence
    hive.py who                            Check who's online (rich presence)
    hive.py backfill [--channel <ch>] [--max N]  H16: replay JetStream → local history
    hive.py test                           Test connectivity + encryption
    hive.py health                         Full system health check
    hive.py share <file> [channel]         Share a file (< 100KB, encrypted)
    hive.py task assign <instance> <desc>  Assign a structured task
    hive.py task list                      List pending tasks
    hive.py task done <task-id>            Mark task complete

Channels: chat, presence, intel, alerts, strategy, build, review, system, dm.<instance>
          Legacy (parallel migration): ideas, tasks, sync
Instances: alpha, beta, gamma
"""

import asyncio
import json
import sys
import os
import time
import base64
import hashlib
import argparse
from pathlib import Path

import ssl
import nats
from nacl.secret import SecretBox
from nacl.utils import random as nacl_random

# --- Config ---
CA_PATH = str(Path.home() / ".openclaw" / ".hive" / "ca.pem")
PRESENCE_DB = Path.home() / ".openclaw" / ".hive" / "presence.json"
TASK_DB = Path.home() / ".openclaw" / ".hive" / "tasks.json"
HISTORY_DB = Path.home() / ".openclaw" / ".hive" / "history.json"
MAX_FILE_SIZE = 100 * 1024  # 100KB
MAX_HISTORY = 500  # max messages to retain in local history
CHUNK_THRESHOLD = 3000  # chars — messages longer than this get auto-chunked
CHUNK_SIZE = 2500  # chars per chunk (leaves room for envelope overhead + encryption)
CHUNK_DB = Path.home() / ".openclaw" / ".hive" / "chunks.json"  # pending chunk reassembly

# --- H27: Anti-flood — rate limiting + dedup ---
DEDUP_DB = Path.home() / ".openclaw" / ".hive" / "dedup.json"
PULSE_RATE_LIMIT_SECS = 1800  # 30 min — presence heartbeat rate limit
DEDUP_WINDOW_SECS = 300       # 5 min — reject identical messages within this window
DEDUP_MAX_ENTRIES = 200       # max hashes to track (FIFO eviction)

# --- H17: Structured Message Types ---
# content_type field in envelope enables machine-parseable routing and rendering.
# Default "text" is backward compatible with all existing messages.
MESSAGE_TYPES = {
    "text": {
        "desc": "Plain text message (default, backward compatible)",
        "fields": None,  # payload is a plain string
        "icon": "💬",
    },
    "status": {
        "desc": "Status report from a sister",
        "fields": ["status", "project?", "progress?", "blockers?", "next?"],
        "icon": "📊",
    },
    "task": {
        "desc": "Structured task assignment",
        "fields": ["task", "assignee", "priority?", "eta?", "context?"],
        "icon": "📋",
    },
    "task_update": {
        "desc": "Task progress or completion update",
        "fields": ["task_id", "status", "note?"],
        "icon": "✅",
    },
    "build": {
        "desc": "Build, CI, or deploy event",
        "fields": ["repo?", "commit?", "status", "details?"],
        "icon": "🔨",
    },
    "proposal": {
        "desc": "Design or architecture proposal",
        "fields": ["title", "summary", "details?"],
        "icon": "💡",
    },
    "vote": {
        "desc": "Vote on a proposal or decision",
        "fields": ["proposal_id", "vote", "reason?"],
        "icon": "🗳️",
    },
    "alert": {
        "desc": "System alert or warning",
        "fields": ["severity", "source", "message", "details?"],
        "icon": "🚨",
    },
    "file": {
        "desc": "File attachment (existing, backward compat)",
        "fields": ["filename", "size", "encoding"],
        "icon": "📎",
    },
    "heartbeat": {
        "desc": "Lightweight alive signal",
        "fields": ["status", "work?", "load?"],
        "icon": "💓",
    },
}

HIVE_CONFIG = {
    "server": "tls://167.233.120.173:4222",
    "instances": {
        "alpha": {"user": "alpha", "password": "hive-alpha-93xk7", "emoji": "🐍", "role": "Companion"},
        "beta":  {"user": "beta",  "password": "hive-beta-47mz2",  "emoji": "🦞", "role": "Manager"},
        "gamma": {"user": "gamma", "password": "hive-gamma-61pr8", "emoji": "🔧", "role": "Builder"},
    },
    # Phase 1 channels (new: intel, alerts, strategy, system). Legacy kept for parallel migration.
    # Phase 2 (after 1 week): add build, review. Then retire tasks, ideas, sync.
    "channels": ["chat", "ideas", "tasks", "sync", "presence",
                  "intel", "alerts", "strategy", "build", "review", "system"],
}


# --- Identity & Keys ---

def get_instance_id():
    """Detect which instance we are from config file or env."""
    config_path = Path.home() / ".openclaw" / ".hive-instance"
    if config_path.exists():
        return config_path.read_text().strip()
    return os.environ.get("HIVE_INSTANCE", "alpha")


def get_key():
    """Load shared encryption key."""
    key_path = Path.home() / ".openclaw" / ".hive-key"
    if not key_path.exists():
        raise FileNotFoundError(f"No hive key at {key_path}.")
    key_b64 = key_path.read_text().strip()
    return base64.b64decode(key_b64)


# --- Encryption ---

def encrypt(message: str, key: bytes) -> str:
    """Encrypt message, return base64-encoded ciphertext."""
    box = SecretBox(key)
    encrypted = box.encrypt(message.encode("utf-8"))
    return base64.b64encode(encrypted).decode("ascii")


def decrypt(ciphertext_b64: str, key: bytes) -> str:
    """Decrypt base64-encoded ciphertext."""
    box = SecretBox(key)
    encrypted = base64.b64decode(ciphertext_b64)
    return box.decrypt(encrypted).decode("utf-8")


# --- Message IDs ---

def make_msg_id(instance_id: str, ts: int) -> str:
    """Generate a short deterministic message ID."""
    raw = f"{instance_id}:{ts}:{os.getpid()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:8]


# --- Envelope v2 ---

def make_envelope(instance_id: str, msg_type: str, payload: str, key: bytes,
                  reply_to: str = None, urgent: bool = False,
                  meta: dict = None, content_type: str = None) -> bytes:
    """Create encrypted message envelope with threading support.

    Args:
        content_type: H17 structured message type (e.g. 'text', 'status', 'task', 'build').
                      If None, defaults to 'text' for backward compatibility.
                      When content_type != 'text', payload should be a JSON string
                      with the fields defined in MESSAGE_TYPES.
    """
    info = HIVE_CONFIG["instances"].get(instance_id, {})
    ts = int(time.time())
    msg_id = make_msg_id(instance_id, ts)

    envelope = {
        "v": 3,  # Bump to v3 for structured message support
        "id": msg_id,
        "from": instance_id,
        "emoji": info.get("emoji", "?"),
        "type": msg_type,
        "ts": ts,
        "payload": encrypt(payload, key),
    }

    # H17: content_type for machine-parseable routing
    ct = content_type or "text"
    if ct != "text":
        envelope["content_type"] = ct

    if reply_to:
        envelope["reply_to"] = reply_to
    if urgent:
        envelope["urgent"] = True
    if meta:
        envelope["meta"] = meta

    return json.dumps(envelope).encode("utf-8")


def make_structured_payload(content_type: str, **fields) -> str:
    """Build a JSON payload for a structured message type.

    Validates required fields against MESSAGE_TYPES definition.
    Returns JSON string ready for make_envelope.
    """
    type_def = MESSAGE_TYPES.get(content_type)
    if not type_def:
        raise ValueError(f"Unknown content_type: {content_type}. Valid: {list(MESSAGE_TYPES.keys())}")

    if type_def["fields"] is None:
        # text type — payload is just the string
        return fields.get("text", "")

    # Validate required fields
    required = [f for f in type_def["fields"] if not f.endswith("?")]
    for req in required:
        if req not in fields:
            raise ValueError(f"content_type '{content_type}' requires field '{req}'")

    payload = {"_type": content_type}
    payload.update(fields)
    return json.dumps(payload)


def parse_structured_payload(env: dict) -> dict:
    """Extract structured data from an envelope.

    Returns dict with '_type' field if structured, or {'_type': 'text', 'text': payload} for plain.
    Backward compatible: v2 envelopes without content_type are treated as 'text'.
    """
    ct = env.get("content_type", "text")
    payload = env.get("payload", "")

    if ct == "text":
        return {"_type": "text", "text": payload}

    try:
        parsed = json.loads(payload)
        if isinstance(parsed, dict):
            parsed.setdefault("_type", ct)
            return parsed
    except (json.JSONDecodeError, TypeError):
        pass

    # Fallback: treat as text
    return {"_type": "text", "text": payload}


# --- H18: Chunked Messages ---

def chunk_message(message: str, chunk_size: int = CHUNK_SIZE) -> list[str]:
    """Split a long message into chunks, preserving line boundaries where possible."""
    if len(message) <= chunk_size:
        return [message]

    chunks = []
    remaining = message
    while remaining:
        if len(remaining) <= chunk_size:
            chunks.append(remaining)
            break

        # Try to split at a line boundary
        split_at = remaining.rfind("\n", 0, chunk_size)
        if split_at < chunk_size // 2:
            # No good line break — split at space
            split_at = remaining.rfind(" ", 0, chunk_size)
        if split_at < chunk_size // 3:
            # No good split — hard cut
            split_at = chunk_size

        chunks.append(remaining[:split_at])
        remaining = remaining[split_at:].lstrip("\n")

    return chunks


def make_chunk_group_id(instance_id: str) -> str:
    """Generate a unique chunk group ID."""
    return hashlib.sha256(f"chunk:{instance_id}:{time.time()}:{os.getpid()}".encode()).hexdigest()[:10]


async def send_chunked(nc, instance_id: str, channel: str, message: str, key: bytes,
                       reply_to: str = None, urgent: bool = False,
                       content_type: str = None, force: bool = False) -> list[str]:
    """Auto-chunk and send a long message as numbered parts.

    Returns list of msg_ids for all chunks sent.
    If message is short enough, sends as single message (no chunking).
    H27: Rejects duplicate messages within DEDUP_WINDOW_SECS unless force=True.
    Returns empty list if deduped.
    """
    # H27: Dedup check — reject identical messages within window
    if not force and _is_duplicate(channel, message):
        return []  # silently dedup

    chunks = chunk_message(message)

    if len(chunks) == 1:
        # No chunking needed — normal send
        subject = f"hive.{channel}"
        data = make_envelope(instance_id, channel, message, key,
                             reply_to=reply_to, urgent=urgent, content_type=content_type)
        await nc.publish(subject, data)
        _record_send(channel, message)  # H27: track for dedup
        env = json.loads(data.decode("utf-8"))
        return [env.get("id", "")]

    # Multi-chunk send
    group_id = make_chunk_group_id(instance_id)
    total = len(chunks)
    msg_ids = []
    subject = f"hive.{channel}"

    for i, chunk_text in enumerate(chunks):
        chunk_meta = {
            "type": "chunk",
            "chunk_group": group_id,
            "chunk_index": i + 1,
            "chunk_total": total,
        }

        data = make_envelope(
            instance_id, channel, chunk_text, key,
            reply_to=reply_to if i == 0 else None,
            urgent=urgent if i == 0 else False,
            content_type=content_type,
            meta=chunk_meta,
        )
        await nc.publish(subject, data)

        env = json.loads(data.decode("utf-8"))
        msg_ids.append(env.get("id", ""))

        # Small delay between chunks to preserve ordering
        await asyncio.sleep(0.05)

    _record_send(channel, message)  # H27: track full message for dedup
    return msg_ids


def _load_chunk_buffer() -> dict:
    """Load pending chunk reassembly buffer."""
    if CHUNK_DB.exists():
        try:
            return json.loads(CHUNK_DB.read_text())
        except Exception:
            pass
    return {}


def _save_chunk_buffer(buf: dict):
    """Save chunk reassembly buffer."""
    CHUNK_DB.parent.mkdir(parents=True, exist_ok=True)
    CHUNK_DB.write_text(json.dumps(buf))


def try_reassemble(env: dict) -> dict | None:
    """Try to reassemble a chunked message.

    Returns the reassembled envelope if all chunks are in, or None if still waiting.
    The reassembled envelope has the full payload and chunk metadata stripped.
    """
    meta = env.get("meta", {})
    if meta.get("type") != "chunk":
        return None

    group_id = meta["chunk_group"]
    index = meta["chunk_index"]
    total = meta["chunk_total"]

    buf = _load_chunk_buffer()

    if group_id not in buf:
        buf[group_id] = {
            "total": total,
            "from": env["from"],
            "channel": env.get("channel", ""),
            "ts": env["ts"],
            "chunks": {},
            "first_env": {k: v for k, v in env.items() if k != "payload"},
        }

    buf[group_id]["chunks"][str(index)] = env["payload"]

    if len(buf[group_id]["chunks"]) >= total:
        # All chunks in — reassemble
        ordered = [buf[group_id]["chunks"][str(i + 1)] for i in range(total)]
        full_payload = "\n".join(ordered)

        # Build reassembled envelope from the first chunk's metadata
        reassembled = dict(buf[group_id]["first_env"])
        reassembled["payload"] = full_payload
        # Mark as reassembled so downstream knows
        reassembled["meta"] = {"type": "reassembled", "chunk_group": group_id, "chunk_total": total}

        # Clean up buffer
        del buf[group_id]
        _save_chunk_buffer(buf)

        return reassembled

    # Still waiting for more chunks
    _save_chunk_buffer(buf)

    # Clean up stale groups (> 5 min old)
    now = int(time.time())
    stale = [gid for gid, g in buf.items() if now - g.get("ts", 0) > 300]
    for gid in stale:
        del buf[gid]
    if stale:
        _save_chunk_buffer(buf)

    return None


def open_envelope(data: bytes, key: bytes) -> dict:
    """Decrypt and parse message envelope."""
    envelope = json.loads(data.decode("utf-8"))
    envelope["payload"] = decrypt(envelope["payload"], key)
    return envelope


# --- TLS / Connection ---

def make_tls_context():
    """Create TLS context for NATS connection."""
    ctx = ssl.create_default_context()
    if os.environ.get("HIVE_TUNNEL") or _use_tunnel():
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    else:
        ctx.load_verify_locations(CA_PATH)
    return ctx


def _use_tunnel():
    tunnel_flag = Path.home() / ".openclaw" / ".hive" / "use-tunnel"
    return tunnel_flag.exists()


def _get_server():
    if os.environ.get("HIVE_TUNNEL") or _use_tunnel():
        return "nats://127.0.0.1:4222"
    return HIVE_CONFIG["server"]


async def hive_connect(instance_id: str):
    """Connect to NATS with TLS + auth."""
    info = HIVE_CONFIG["instances"][instance_id]
    return await nats.connect(
        _get_server(),
        user=info["user"],
        password=info["password"],
        tls=make_tls_context(),
    )


# --- Formatting ---

def format_message(env: dict, subject: str) -> str:
    """Pretty-print a received message."""
    channel = subject.replace("hive.", "")
    ts = time.strftime("%H:%M:%S", time.localtime(env["ts"]))
    emoji = env.get("emoji", "?")
    sender = env["from"]
    msg_id = env.get("id", "")

    parts = []

    # Urgent flag
    if env.get("urgent"):
        parts.append("🚨 URGENT")

    # Reply context
    if env.get("reply_to"):
        parts.append(f"↩ re:{env['reply_to']}")

    # H18: Reassembled chunk indicator
    meta = env.get("meta", {})
    if meta.get("type") == "reassembled":
        parts.append(f"📦 {meta.get('chunk_total', '?')} parts")

    prefix = f" ({' | '.join(parts)})" if parts else ""
    id_tag = f" [{msg_id}]" if msg_id else ""

    # H17: Structured message rendering
    ct = env.get("content_type", "text")
    structured = parse_structured_payload(env)
    type_icon = MESSAGE_TYPES.get(ct, {}).get("icon", "")

    if ct == "status":
        status = structured.get("status", "unknown")
        project = structured.get("project", "")
        progress = structured.get("progress", "")
        blockers = structured.get("blockers", "")
        next_item = structured.get("next", "")
        lines = [f"{type_icon} Status: {status}"]
        if project:
            lines.append(f"Project: {project}")
        if progress:
            lines.append(f"Progress: {progress}")
        if blockers:
            lines.append(f"Blockers: {blockers}")
        if next_item:
            lines.append(f"Next: {next_item}")
        body = " | ".join(lines)
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {body}{id_tag}"

    if ct == "task":
        task_desc = structured.get("task", env["payload"])
        assignee = structured.get("assignee", "?")
        priority = structured.get("priority", "")
        eta = structured.get("eta", "")
        pri_tag = f" [{priority}]" if priority else ""
        eta_tag = f" ETA:{eta}" if eta else ""
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {type_icon} Task → {assignee}{pri_tag}: {task_desc}{eta_tag}{id_tag}"

    if ct == "task_update":
        task_id = structured.get("task_id", "?")
        status = structured.get("status", "?")
        note = structured.get("note", "")
        note_tag = f" — {note}" if note else ""
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {type_icon} Task [{task_id}] → {status}{note_tag}{id_tag}"

    if ct == "build":
        repo = structured.get("repo", "")
        commit = structured.get("commit", "")
        status = structured.get("status", "?")
        details = structured.get("details", "")
        repo_tag = f" {repo}" if repo else ""
        commit_tag = f" @{commit[:8]}" if commit else ""
        details_tag = f" — {details}" if details else ""
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {type_icon}{repo_tag}{commit_tag} [{status}]{details_tag}{id_tag}"

    if ct == "proposal":
        title = structured.get("title", "?")
        summary = structured.get("summary", "")
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {type_icon} Proposal: {title} — {summary}{id_tag}"

    if ct == "vote":
        prop_id = structured.get("proposal_id", "?")
        vote = structured.get("vote", "?")
        reason = structured.get("reason", "")
        reason_tag = f" — {reason}" if reason else ""
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {type_icon} Vote on [{prop_id}]: {vote}{reason_tag}{id_tag}"

    if ct == "alert":
        severity = structured.get("severity", "?")
        source = structured.get("source", "?")
        message = structured.get("message", env["payload"])
        sev_icons = {"critical": "🔴", "warning": "🟡", "info": "🔵"}
        sev_icon = sev_icons.get(severity, "⚪")
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {type_icon}{sev_icon} [{severity}] {source}: {message}{id_tag}"

    if ct == "heartbeat":
        status = structured.get("status", "alive")
        work = structured.get("work", "")
        work_tag = f" — {work}" if work else ""
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {type_icon} {status}{work_tag}{id_tag}"

    # Legacy: file sharing via meta
    meta = env.get("meta", {})
    if meta.get("type") == "file":
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: 📎 {meta['filename']} ({meta['size']} bytes){id_tag}"

    # Legacy: structured task via meta
    if meta.get("type") == "task":
        status = meta.get("status", "new")
        assignee = meta.get("assignee", "?")
        task_id = meta.get("task_id", "?")
        icons = {"new": "📋", "done": "✅", "cancelled": "❌"}
        icon = icons.get(status, "📋")
        return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {icon} Task [{task_id}] → {assignee}: {env['payload']}{id_tag}"

    return f"[{ts}] #{channel} {emoji} {sender}{prefix}: {env['payload']}{id_tag}"


# --- Presence DB (local) ---

def _update_presence(instance_id: str, ts: int):
    """Update local presence database."""
    db = {}
    if PRESENCE_DB.exists():
        try:
            db = json.loads(PRESENCE_DB.read_text())
        except Exception:
            db = {}
    db[instance_id] = ts
    PRESENCE_DB.write_text(json.dumps(db))


def _get_presence() -> dict:
    """Read local presence database."""
    if PRESENCE_DB.exists():
        try:
            return json.loads(PRESENCE_DB.read_text())
        except Exception:
            pass
    return {}


# --- H27: Anti-flood helpers ---

def _load_dedup() -> dict:
    """Load dedup state: {hash: timestamp, ...} + pulse tracking."""
    if DEDUP_DB.exists():
        try:
            return json.loads(DEDUP_DB.read_text())
        except Exception:
            pass
    return {"hashes": {}, "last_pulse": {}}


def _save_dedup(state: dict):
    """Save dedup state, evicting old entries."""
    DEDUP_DB.parent.mkdir(parents=True, exist_ok=True)
    now = int(time.time())
    # Evict expired hashes
    hashes = state.get("hashes", {})
    hashes = {h: ts for h, ts in hashes.items() if now - ts < DEDUP_WINDOW_SECS}
    # FIFO eviction if still too many
    if len(hashes) > DEDUP_MAX_ENTRIES:
        sorted_h = sorted(hashes.items(), key=lambda x: x[1])
        hashes = dict(sorted_h[-DEDUP_MAX_ENTRIES:])
    state["hashes"] = hashes
    DEDUP_DB.write_text(json.dumps(state))


def _content_hash(channel: str, message: str) -> str:
    """Hash channel + message content for dedup. Ignores timestamps."""
    raw = f"{channel}:{message.strip()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _is_duplicate(channel: str, message: str) -> bool:
    """Check if this exact message was sent to this channel recently."""
    state = _load_dedup()
    h = _content_hash(channel, message)
    hashes = state.get("hashes", {})
    now = int(time.time())
    if h in hashes and now - hashes[h] < DEDUP_WINDOW_SECS:
        return True
    return False


def _record_send(channel: str, message: str):
    """Record a sent message for dedup tracking."""
    state = _load_dedup()
    h = _content_hash(channel, message)
    state.setdefault("hashes", {})[h] = int(time.time())
    _save_dedup(state)


def _is_pulse_rate_limited(instance_id: str, status: str, work: str = None) -> bool:
    """Check if pulse should be suppressed (same content within 30 min)."""
    state = _load_dedup()
    last = state.get("last_pulse", {}).get(instance_id)
    if not last:
        return False
    now = int(time.time())
    if now - last.get("ts", 0) < PULSE_RATE_LIMIT_SECS:
        # Rate limited — but allow if content actually changed
        if last.get("status") == status and last.get("work") == work:
            return True
    return False


def _record_pulse(instance_id: str, status: str, work: str = None):
    """Record a pulse for rate limiting."""
    state = _load_dedup()
    state.setdefault("last_pulse", {})[instance_id] = {
        "ts": int(time.time()),
        "status": status,
        "work": work,
    }
    _save_dedup(state)


# --- Task DB (local) ---

def _load_tasks() -> list:
    if TASK_DB.exists():
        try:
            return json.loads(TASK_DB.read_text())
        except Exception:
            pass
    return []


def _save_tasks(tasks: list):
    TASK_DB.write_text(json.dumps(tasks, indent=2))


def _make_task_id(desc: str) -> str:
    return hashlib.sha256(f"{desc}:{time.time()}".encode()).hexdigest()[:6]


# --- History DB (local) ---

def _load_history() -> list:
    """Load message history from local store."""
    if HISTORY_DB.exists():
        try:
            return json.loads(HISTORY_DB.read_text())
        except Exception:
            pass
    return []


def _save_history(history: list):
    """Save message history, keeping only the most recent MAX_HISTORY entries."""
    if len(history) > MAX_HISTORY:
        history = history[-MAX_HISTORY:]
    HISTORY_DB.write_text(json.dumps(history, indent=None))


def _store_message(env: dict, subject: str):
    """Append a decoded envelope to local history."""
    channel = subject.replace("hive.", "")
    history = _load_history()
    entry = {
        "id": env.get("id", ""),
        "from": env["from"],
        "emoji": env.get("emoji", "?"),
        "channel": channel,
        "payload": env["payload"],
        "ts": env["ts"],
        "reply_to": env.get("reply_to"),
        "urgent": env.get("urgent", False),
        "meta": env.get("meta", {}),
    }
    # H17: Preserve content_type for structured messages
    ct = env.get("content_type")
    if ct and ct != "text":
        entry["content_type"] = ct
    # Deduplicate by id
    existing_ids = {h["id"] for h in history if h.get("id")}
    if entry["id"] and entry["id"] in existing_ids:
        return
    history.append(entry)
    _save_history(history)


def _emit_read_receipt(nc, instance_id: str, key: bytes, msg_id: str, channel: str):
    """Create a read receipt envelope (to be published by caller)."""
    return make_envelope(
        instance_id, "system", json.dumps({
            "type": "read_receipt",
            "msg_id": msg_id,
            "channel": channel,
            "reader": instance_id,
            "ts": int(time.time()),
        }), key,
        meta={"type": "read_receipt", "msg_id": msg_id},
    )


# --- Commands ---

async def cmd_send(args):
    """Send a message to a channel. Auto-chunks long messages (H18)."""
    instance_id = get_instance_id()
    key = get_key()

    nc = await hive_connect(instance_id)

    ct = getattr(args, 'content_type', None)
    force = getattr(args, 'force', False)
    msg_ids = await send_chunked(
        nc, instance_id, args.channel, args.message, key,
        reply_to=getattr(args, 'reply_to', None),
        urgent=getattr(args, 'urgent', False),
        content_type=ct,
        force=force,
    )
    await nc.flush()
    await nc.close()

    # H27: Dedup suppression
    if not msg_ids:
        print(f"⚡ Dedup: identical message to #{args.channel} suppressed (sent <{DEDUP_WINDOW_SECS}s ago)")
        return

    urgent_tag = " 🚨" if getattr(args, 'urgent', False) else ""
    reply_tag = f" (↩ {args.reply_to})" if getattr(args, 'reply_to', None) else ""
    type_tag = f" ({ct})" if ct and ct != "text" else ""

    if len(msg_ids) == 1:
        print(f"✓ Sent to #{args.channel}{type_tag}{urgent_tag}{reply_tag} [{msg_ids[0]}]")
    else:
        print(f"✓ Sent to #{args.channel}{type_tag}{urgent_tag}{reply_tag} ({len(msg_ids)} chunks) [{msg_ids[0]}..{msg_ids[-1]}]")

    # H15: Store own messages in history (store the full message, not chunks)
    try:
        subject = f"hive.{args.channel}"
        store_env = {
            "v": 3,
            "id": msg_ids[0],
            "from": instance_id,
            "emoji": HIVE_CONFIG["instances"].get(instance_id, {}).get("emoji", "?"),
            "type": args.channel,
            "ts": int(time.time()),
            "payload": args.message,
        }
        if ct and ct != "text":
            store_env["content_type"] = ct
        _store_message(store_env, subject)
    except Exception:
        pass  # best-effort


async def cmd_send_structured(args):
    """Send a structured message (H17).

    Usage:
        hive.py send-structured <channel> <content_type> <json_fields>
        hive.py send-structured build build '{"repo":"zerone","commit":"abc123","status":"passed"}'
        hive.py send-structured strategy status '{"status":"active","project":"Hive","progress":"H17 shipping"}'
    """
    instance_id = get_instance_id()
    key = get_key()

    ct = args.content_type
    if ct not in MESSAGE_TYPES:
        print(f"✗ Unknown content_type: {ct}. Valid: {list(MESSAGE_TYPES.keys())}")
        return

    # Parse fields JSON
    try:
        fields = json.loads(args.fields_json)
    except json.JSONDecodeError as e:
        print(f"✗ Invalid JSON: {e}")
        return

    # Build structured payload
    try:
        payload = make_structured_payload(ct, **fields)
    except ValueError as e:
        print(f"✗ {e}")
        return

    nc = await hive_connect(instance_id)
    subject = f"hive.{args.channel}"
    data = make_envelope(
        instance_id, args.channel, payload, key,
        reply_to=getattr(args, 'reply_to', None),
        urgent=getattr(args, 'urgent', False),
        content_type=ct,
    )
    await nc.publish(subject, data)
    await nc.flush()
    await nc.close()

    env = json.loads(data.decode("utf-8"))
    msg_id = env.get("id", "")
    type_icon = MESSAGE_TYPES[ct]["icon"]
    print(f"✓ Sent {type_icon} {ct} to #{args.channel} [{msg_id}]")

    try:
        decrypted_env = open_envelope(data, key)
        _store_message(decrypted_env, subject)
    except Exception:
        pass


async def cmd_listen(args):
    """Listen for messages on channels."""
    instance_id = get_instance_id()
    key = get_key()
    info = HIVE_CONFIG["instances"][instance_id]

    nc = await hive_connect(instance_id)

    channel = args.channel or ">"
    subject = f"hive.{channel}" if channel != ">" else "hive.>"

    async def handler(msg):
        try:
            env = open_envelope(msg.data, key)
            if env["from"] != instance_id:
                # Update presence tracking
                _update_presence(env["from"], env["ts"])
                print(format_message(env, msg.subject))
        except Exception as e:
            print(f"[decrypt error: {e}]")

    await nc.subscribe(subject, cb=handler)
    print(f"{info['emoji']} {instance_id} listening on {subject}...")
    print("Press Ctrl+C to stop.\n")

    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        await nc.close()


async def cmd_check(args):
    """Check for new persistent messages (JetStream). Auto-publishes presence beacon.

    Presence beacons and system read-receipts are hidden by default.

    Filters:
        --include-presence  Show presence heartbeat messages
        --all               Show all messages including presence and system
        --channel <ch>      Show only messages from this channel
        --urgent-only       Show only urgent messages
    """
    instance_id = get_instance_id()
    key = get_key()

    # Parse filter options
    show_all = getattr(args, 'show_all', False)
    include_presence = getattr(args, 'include_presence', False) or show_all
    skip_presence = not include_presence  # default: hide presence
    filter_channel = getattr(args, 'channel', None)
    urgent_only = getattr(args, 'urgent_only', False)

    nc = await hive_connect(instance_id)
    js = nc.jetstream()

    # Auto-beacon: publish rich presence on every check
    beacon = make_envelope(instance_id, "presence", json.dumps({
        "instance": instance_id,
        "role": HIVE_CONFIG["instances"][instance_id]["role"],
        "status": "heartbeat",
        "ts": int(time.time()),
        "channels": HIVE_CONFIG["channels"],
        "version": "v3",
    }), key)
    await nc.publish("hive.presence", beacon)
    await nc.flush()

    # Update own presence
    _update_presence(instance_id, int(time.time()))

    durable = f"{instance_id}-inbox"
    all_envs = []  # (env, subject) tuples for all received messages
    messages = []  # formatted strings after filtering
    tasks_received = []
    receipt_batch = []  # read receipts to publish

    try:
        sub = await js.subscribe("hive.>", durable=durable)
        while True:
            try:
                msg = await sub.next_msg(timeout=1)
                try:
                    env = open_envelope(msg.data, key)
                    if env["from"] != instance_id:
                        # Track presence from any message
                        _update_presence(env["from"], env["ts"])

                        # H18: Check if this is a chunk — try reassembly
                        meta = env.get("meta", {})
                        if meta.get("type") == "chunk":
                            env["channel"] = msg.subject.replace("hive.", "")
                            reassembled = try_reassemble(env)
                            if reassembled:
                                # Full message reassembled — use it instead
                                _store_message(reassembled, msg.subject)
                                channel = msg.subject.replace("hive.", "")
                                if channel != "presence" and channel != "system":
                                    receipt = _emit_read_receipt(nc, instance_id, key, reassembled.get("id", ""), channel)
                                    receipt_batch.append(receipt)
                                all_envs.append((reassembled, msg.subject))
                            # else: still waiting for more chunks, don't display yet
                            await msg.ack()
                            continue

                        # Store ALL messages to history (before filtering)
                        _store_message(env, msg.subject)

                        # Queue read receipt for non-presence messages
                        channel = msg.subject.replace("hive.", "")
                        if channel != "presence" and channel != "system":
                            receipt = _emit_read_receipt(nc, instance_id, key, env.get("id", ""), channel)
                            receipt_batch.append(receipt)

                        # Collect structured tasks assigned to us
                        if meta.get("type") == "task" and meta.get("assignee") == instance_id:
                            tasks_received.append({
                                "task_id": meta["task_id"],
                                "from": env["from"],
                                "desc": env["payload"],
                                "eta": meta.get("eta"),
                                "ts": env["ts"],
                                "status": "new",
                            })

                        all_envs.append((env, msg.subject))
                except Exception:
                    pass
                await msg.ack()
            except Exception:
                break
        await sub.unsubscribe()
    except Exception as e:
        print(f"JetStream error: {e}")

    # Publish read receipts in batch
    for receipt in receipt_batch:
        try:
            await nc.publish("hive.system", receipt)
        except Exception:
            pass
    if receipt_batch:
        await nc.flush()

    await nc.close()

    # Store received tasks
    if tasks_received:
        existing = _load_tasks()
        existing_ids = {t["task_id"] for t in existing}
        for t in tasks_received:
            if t["task_id"] not in existing_ids:
                existing.append(t)
        _save_tasks(existing)

    # Apply filters
    for env, subject in all_envs:
        channel = subject.replace("hive.", "")

        # Filter: skip presence
        if skip_presence and channel == "presence":
            continue

        # Filter: channel
        if filter_channel and channel != filter_channel:
            continue

        # Filter: urgent only
        if urgent_only and not env.get("urgent"):
            continue

        # Skip read receipt system messages from display
        meta = env.get("meta", {})
        if meta.get("type") == "read_receipt":
            continue

        messages.append(format_message(env, subject))

    # Count totals for summary
    total_raw = len(all_envs)
    total_shown = len(messages)
    total_hidden = total_raw - total_shown
    active_filters = []
    if skip_presence and not include_presence:
        active_filters.append("no-presence")
    if filter_channel:
        active_filters.append(f"#{filter_channel}")
    if urgent_only:
        active_filters.append("urgent-only")

    # Output
    if messages:
        urgent = [m for m in messages if "🚨 URGENT" in m]
        normal = [m for m in messages if "🚨 URGENT" not in m]

        filter_note = ""
        if active_filters:
            filter_note = f" (filter: {', '.join(active_filters)} | {total_hidden} hidden)"

        print(f"📬 {total_shown} message(s){filter_note}:")
        if urgent:
            print(f"\n  ⚡ URGENT ({len(urgent)}):")
            for m in urgent:
                print(f"  {m}")
        if normal:
            if urgent:
                print(f"\n  📨 Normal ({len(normal)}):")
            for m in normal:
                print(f"  {m}")
    else:
        if total_hidden > 0:
            print(f"📭 No messages matching filter ({total_hidden} hidden by filter: {', '.join(active_filters)})")
        else:
            print("📭 No new messages")

    return messages


async def cmd_history(args):
    """Browse local message history with filters.

    Filters:
        channel     Show only messages from this channel
        --hours N   Show messages from last N hours (default: 24)
        --from X    Show only messages from instance X
        --search T  Show messages containing text T
    """
    history = _load_history()
    if not history:
        print("📜 No message history yet. Run 'check' first to populate.")
        return

    # Parse filters
    channel = getattr(args, 'channel', None)
    hours = getattr(args, 'hours', 24) or 24
    from_inst = getattr(args, 'from_instance', None)
    search = getattr(args, 'search', None)

    cutoff = int(time.time()) - (hours * 3600)

    filtered = []
    for entry in history:
        # Time filter
        if entry["ts"] < cutoff:
            continue
        # Channel filter
        if channel and entry["channel"] != channel:
            continue
        # Instance filter
        if from_inst and entry["from"] != from_inst:
            continue
        # Search filter
        if search and search.lower() not in entry["payload"].lower():
            continue
        # Skip presence heartbeats and read receipts
        if entry["channel"] == "presence":
            continue
        meta = entry.get("meta", {})
        if meta.get("type") == "read_receipt":
            continue

        filtered.append(entry)

    if not filtered:
        filters = []
        if channel:
            filters.append(f"#{channel}")
        if from_inst:
            filters.append(f"from:{from_inst}")
        if search:
            filters.append(f'search:"{search}"')
        print(f"📜 No messages in last {hours}h" + (f" ({', '.join(filters)})" if filters else ""))
        return

    # Group by channel for readability
    by_channel = {}
    for entry in filtered:
        ch = entry["channel"]
        if ch not in by_channel:
            by_channel[ch] = []
        by_channel[ch].append(entry)

    print(f"📜 {len(filtered)} message(s) in last {hours}h:")
    for ch in sorted(by_channel.keys()):
        entries = by_channel[ch]
        print(f"\n  #{ch} ({len(entries)}):")
        for e in entries:
            ts = time.strftime("%m-%d %H:%M", time.localtime(e["ts"]))
            emoji = e.get("emoji", "?")
            sender = e["from"]
            msg_id = e.get("id", "")
            urgent = " 🚨" if e.get("urgent") else ""
            reply = f" ↩{e['reply_to']}" if e.get("reply_to") else ""

            # H17: show content_type if structured
            ct = e.get("content_type", "")
            ct_tag = f" [{ct}]" if ct and ct != "text" else ""

            # Truncate long messages for display
            payload = e["payload"]
            if len(payload) > 200:
                payload = payload[:197] + "..."

            print(f"    [{ts}] {emoji} {sender}{urgent}{reply}{ct_tag}: {payload} [{msg_id}]")


async def cmd_thread(args):
    """Show full reply chain for a message ID."""
    history = _load_history()
    if not history:
        print("📜 No message history. Run 'check' first.")
        return

    target_id = args.msg_id

    # Build index
    by_id = {h["id"]: h for h in history if h.get("id")}
    # Build reply tree: parent_id -> [children]
    children = {}
    for h in history:
        if h.get("reply_to"):
            parent = h["reply_to"]
            if parent not in children:
                children[parent] = []
            children[parent].append(h)

    # Find root of thread (walk up)
    current = target_id
    while True:
        entry = by_id.get(current)
        if not entry or not entry.get("reply_to"):
            break
        current = entry["reply_to"]

    root_id = current
    root = by_id.get(root_id)

    if not root:
        print(f"✗ Message [{target_id}] not found in local history. Try 'check' first.")
        return

    # Walk down the tree
    def print_thread(msg_id, depth=0):
        entry = by_id.get(msg_id)
        if not entry:
            return
        indent = "  " * (depth + 1)
        ts = time.strftime("%m-%d %H:%M", time.localtime(entry["ts"]))
        emoji = entry.get("emoji", "?")
        sender = entry["from"]
        urgent = " 🚨" if entry.get("urgent") else ""
        ch = entry.get("channel", "?")

        payload = entry["payload"]
        if len(payload) > 300:
            payload = payload[:297] + "..."

        print(f"{indent}[{ts}] #{ch} {emoji} {sender}{urgent}: {payload} [{entry['id']}]")

        # Print children sorted by timestamp
        for child in sorted(children.get(msg_id, []), key=lambda x: x["ts"]):
            print_thread(child["id"], depth + 1)

    print(f"🧵 Thread from [{root_id}]:")
    print_thread(root_id)

    # Count total messages in thread
    def count_thread(msg_id):
        total = 1
        for child in children.get(msg_id, []):
            total += count_thread(child["id"])
        return total

    total = count_thread(root_id)
    print(f"\n  ({total} message(s) in thread)")


async def cmd_presence(args):
    """Announce rich presence on the hive.

    Options:
        --status <text>   Current status (e.g. 'busy', 'available', 'building')
        --work <text>     What you're working on (e.g. 'hive infra sprint')
    """
    instance_id = get_instance_id()
    key = get_key()
    info = HIVE_CONFIG["instances"][instance_id]

    status_text = getattr(args, 'status_text', None) or "online"
    work_text = getattr(args, 'work_text', None)

    presence_data = {
        "instance": instance_id,
        "role": info["role"],
        "status": status_text,
        "ts": int(time.time()),
        "channels": HIVE_CONFIG["channels"],
        "version": "v3",
    }
    if work_text:
        presence_data["work"] = work_text

    nc = await hive_connect(instance_id)
    payload = json.dumps(presence_data)
    data = make_envelope(instance_id, "presence", payload, key)
    await nc.publish("hive.presence", data)
    await nc.flush()
    await nc.close()

    _update_presence(instance_id, int(time.time()))
    work_note = f" | working on: {work_text}" if work_text else ""
    print(f"{info['emoji']} {instance_id} announced presence ({status_text}{work_note})")


async def cmd_pulse(args):
    """H26: Send a structured heartbeat pulse with session state.

    This is the sister presence protocol — lightweight, queryable, machine-parseable.
    Publishes a structured heartbeat to hive.presence with content_type='heartbeat'.

    Usage:
        hive.py pulse                           # Basic alive signal
        hive.py pulse --work "building H17"     # With current work
        hive.py pulse --status building         # With custom status
    """
    instance_id = get_instance_id()
    key = get_key()
    info = HIVE_CONFIG["instances"][instance_id]

    status = getattr(args, 'status_text', None) or "alive"
    work = getattr(args, 'work_text', None)
    force = getattr(args, 'force', False)

    # H27: Rate limit — max 1 pulse per 30 min if content unchanged
    if not force and _is_pulse_rate_limited(instance_id, status, work):
        remaining = PULSE_RATE_LIMIT_SECS - (int(time.time()) - _load_dedup().get("last_pulse", {}).get(instance_id, {}).get("ts", 0))
        print(f"⚡ Pulse rate-limited ({remaining}s remaining). Use --force to override.")
        return

    # Build structured heartbeat payload
    hb_fields = {
        "status": status,
        "instance": instance_id,
        "role": info["role"],
        "ts": int(time.time()),
        "version": "v3",
    }
    if work:
        hb_fields["work"] = work

    payload = make_structured_payload("heartbeat", **{
        "status": status,
        **({"work": work} if work else {}),
    })

    nc = await hive_connect(instance_id)
    data = make_envelope(
        instance_id, "presence", payload, key,
        content_type="heartbeat",
    )
    await nc.publish("hive.presence", data)
    await nc.flush()
    await nc.close()

    _update_presence(instance_id, int(time.time()))
    _record_pulse(instance_id, status, work)  # H27: track for rate limiting
    work_note = f" | working on: {work}" if work else ""
    print(f"💓 {info['emoji']} {instance_id} pulse ({status}{work_note})")


async def cmd_who(args):
    """Check who's online using local presence DB (updated from JetStream messages)."""
    instance_id = get_instance_id()

    # First do a check to pull latest messages and update presence
    # (this ensures presence DB is fresh)
    key = get_key()
    nc = await hive_connect(instance_id)
    js = nc.jetstream()

    # Publish presence query + own beacon
    beacon = make_envelope(instance_id, "presence", json.dumps({
        "instance": instance_id,
        "role": HIVE_CONFIG["instances"][instance_id]["role"],
        "status": "who",
        "ts": int(time.time()),
    }), key)
    await nc.publish("hive.presence", beacon)
    await nc.flush()

    # Pull recent presence messages from JetStream
    durable = f"{instance_id}-presence"
    try:
        sub = await js.subscribe("hive.presence", durable=durable)
        while True:
            try:
                msg = await sub.next_msg(timeout=1)
                try:
                    env = open_envelope(msg.data, key)
                    _update_presence(env["from"], env["ts"])
                except Exception:
                    pass
                await msg.ack()
            except Exception:
                break
        await sub.unsubscribe()
    except Exception:
        pass

    await nc.close()

    _update_presence(instance_id, int(time.time()))

    # Also check history for rich presence data
    history = _load_history()
    rich_presence = {}  # instance -> latest presence payload
    for h in reversed(history):
        if h["channel"] == "presence" and h["from"] not in rich_presence:
            try:
                pdata = json.loads(h["payload"]) if isinstance(h["payload"], str) and h["payload"].startswith("{") else {}
                if pdata.get("version") == "v3":
                    rich_presence[h["from"]] = pdata
            except Exception:
                pass
        if len(rich_presence) >= len(HIVE_CONFIG["instances"]):
            break

    # Read presence DB
    presence = _get_presence()
    now = int(time.time())

    print("Instance Status:")
    for inst, info in HIVE_CONFIG["instances"].items():
        last_seen = presence.get(inst)
        if last_seen:
            ago = now - last_seen
            if ago < 60:
                status = f"🟢 active ({ago}s ago)"
            elif ago < 600:  # 10 min
                status = f"🟡 recent ({ago // 60}m ago)"
            elif ago < 3600:
                status = f"🟠 idle ({ago // 60}m ago)"
            else:
                status = f"🔴 offline ({ago // 3600}h ago)"
        else:
            status = "⚫ never seen"

        # Append rich presence if available
        rp = rich_presence.get(inst, {})
        extras = []
        if rp.get("status") and rp["status"] not in ("heartbeat", "online", "who"):
            extras.append(rp["status"])
        if rp.get("work"):
            extras.append(f"working on: {rp['work']}")
        if rp.get("channels"):
            ch_count = len(rp["channels"])
            extras.append(f"{ch_count} channels")
        if rp.get("version"):
            extras.append(rp["version"])

        extra_str = f" — {', '.join(extras)}" if extras else ""
        print(f"  {info['emoji']} {inst} ({info['role']}): {status}{extra_str}")


async def cmd_share(args):
    """Share a file over the hive (< 100KB, encrypted)."""
    instance_id = get_instance_id()
    key = get_key()

    filepath = Path(args.file)
    if not filepath.exists():
        print(f"✗ File not found: {filepath}")
        return

    size = filepath.stat().st_size
    if size > MAX_FILE_SIZE:
        print(f"✗ File too large: {size} bytes (max {MAX_FILE_SIZE})")
        return

    content = filepath.read_bytes()
    content_b64 = base64.b64encode(content).decode("ascii")

    channel = args.channel or "sync"

    nc = await hive_connect(instance_id)

    data = make_envelope(
        instance_id, channel,
        content_b64, key,
        meta={
            "type": "file",
            "filename": filepath.name,
            "size": size,
            "encoding": "base64",
        },
    )
    subject = f"hive.{channel}"
    await nc.publish(subject, data)
    await nc.flush()
    await nc.close()

    print(f"✓ Shared {filepath.name} ({size} bytes) on #{channel}")


async def cmd_receive_files(channel: str, instance_id: str, key: bytes, output_dir: Path):
    """Extract files from checked messages (called internally)."""
    # This is handled in cmd_check — files are auto-saved to .hive/files/
    pass


async def cmd_task(args):
    """Manage structured tasks."""
    instance_id = get_instance_id()
    key = get_key()

    if args.task_action == "assign":
        assignee = args.assignee
        desc = " ".join(args.description)
        eta = getattr(args, 'eta', None)
        task_id = _make_task_id(desc)

        nc = await hive_connect(instance_id)
        data = make_envelope(
            instance_id, "tasks", desc, key,
            meta={
                "type": "task",
                "task_id": task_id,
                "assignee": assignee,
                "status": "new",
                "eta": eta,
            },
        )
        await nc.publish("hive.tasks", data)
        await nc.flush()
        await nc.close()

        # Store locally too
        tasks = _load_tasks()
        tasks.append({
            "task_id": task_id,
            "from": instance_id,
            "assignee": assignee,
            "desc": desc,
            "eta": eta,
            "ts": int(time.time()),
            "status": "new",
        })
        _save_tasks(tasks)

        print(f"✓ Task [{task_id}] assigned to {assignee}: {desc}")

    elif args.task_action == "list":
        tasks = _load_tasks()
        pending = [t for t in tasks if t.get("status") == "new"]
        done = [t for t in tasks if t.get("status") == "done"]

        if not tasks:
            print("📋 No tasks")
            return

        if pending:
            print(f"📋 Pending ({len(pending)}):")
            for t in pending:
                eta = f" | ETA: {t['eta']}" if t.get('eta') else ""
                assignee_tag = f" → {t['assignee']}" if t.get('assignee') else ""
                ts = time.strftime("%H:%M", time.localtime(t["ts"]))
                print(f"  [{t['task_id']}]{assignee_tag}: {t['desc']}{eta} ({ts})")

        if done:
            print(f"✅ Done ({len(done)}):")
            for t in done[-5:]:  # Show last 5
                print(f"  [{t['task_id']}]: {t['desc']}")

    elif args.task_action == "done":
        task_id = args.task_id
        tasks = _load_tasks()
        found = False
        for t in tasks:
            if t["task_id"] == task_id:
                t["status"] = "done"
                t["completed_at"] = int(time.time())
                found = True
                break

        if found:
            _save_tasks(tasks)

            # Announce on hive
            nc = await hive_connect(instance_id)
            data = make_envelope(
                instance_id, "tasks",
                f"Completed: {t['desc']}", key,
                meta={
                    "type": "task",
                    "task_id": task_id,
                    "assignee": instance_id,
                    "status": "done",
                },
            )
            await nc.publish("hive.tasks", data)
            await nc.flush()
            await nc.close()

            print(f"✅ Task [{task_id}] marked done")
        else:
            print(f"✗ Task [{task_id}] not found")


async def cmd_backfill(args):
    """H16: Backfill local history from JetStream on cold start.

    Replays all retained messages from JetStream into local history DB.
    Uses a separate durable consumer to avoid affecting the normal inbox.
    Idempotent: skips messages already in local history (dedup by id).

    Usage:
        hive.py backfill                # Backfill all channels
        hive.py backfill --channel chat  # Backfill specific channel
        hive.py backfill --max 200       # Limit messages to replay
    """
    instance_id = get_instance_id()
    key = get_key()

    channel = getattr(args, 'channel', None)
    max_msgs = getattr(args, 'max_count', None) or 500

    nc = await hive_connect(instance_id)
    js = nc.jetstream()

    subject = f"hive.{channel}" if channel else "hive.>"
    durable = f"{instance_id}-backfill"

    existing_history = _load_history()
    existing_ids = {h["id"] for h in existing_history if h.get("id")}

    added = 0
    skipped = 0
    errors = 0

    try:
        # Use deliver_policy=all to get everything JetStream has retained
        from nats.js.api import ConsumerConfig, DeliverPolicy
        sub = await js.subscribe(
            subject,
            durable=durable,
            config=ConsumerConfig(deliver_policy=DeliverPolicy.ALL),
        )

        count = 0
        while count < max_msgs:
            try:
                msg = await sub.next_msg(timeout=2)
                count += 1
                try:
                    env = open_envelope(msg.data, key)

                    # Skip own presence beacons and read receipts
                    ch = msg.subject.replace("hive.", "")
                    if ch == "presence":
                        _update_presence(env["from"], env["ts"])
                        await msg.ack()
                        skipped += 1
                        continue

                    meta = env.get("meta", {})
                    if meta.get("type") == "read_receipt":
                        await msg.ack()
                        skipped += 1
                        continue

                    msg_id = env.get("id", "")
                    if msg_id and msg_id in existing_ids:
                        await msg.ack()
                        skipped += 1
                        continue

                    _store_message(env, msg.subject)
                    if msg_id:
                        existing_ids.add(msg_id)
                    added += 1
                except Exception:
                    errors += 1
                await msg.ack()
            except Exception:
                break  # No more messages

        await sub.unsubscribe()
    except Exception as e:
        print(f"✗ Backfill error: {e}")
        await nc.close()
        return

    await nc.close()

    ch_tag = f" #{channel}" if channel else ""
    print(f"📥 Backfill{ch_tag}: +{added} new, {skipped} skipped, {errors} errors (scanned {added + skipped + errors})")


async def cmd_health(args):
    """Full system health check — tunnel, NATS, encryption, JetStream, presence."""
    instance_id = get_instance_id()
    key = get_key()
    info = HIVE_CONFIG["instances"][instance_id]
    issues = []

    print(f"🏥 Health Check — {info['emoji']} {instance_id} ({info['role']})")
    print(f"   Server: {_get_server()}")
    print(f"   Tunnel: {'yes' if _use_tunnel() else 'no'}")

    # 1. SSH tunnel (if using tunnel mode)
    if _use_tunnel():
        import subprocess
        result = subprocess.run(
            ["pgrep", "-f", "ssh.*4222.*167.233"],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            print("   SSH tunnel: ✓ (process alive)")
        else:
            print("   SSH tunnel: ✗ (process not found)")
            issues.append("SSH tunnel dead")

    # 2. Encryption
    try:
        test_msg = "health-check"
        assert decrypt(encrypt(test_msg, key), key) == test_msg
        print("   Encryption: ✓")
    except Exception as e:
        print(f"   Encryption: ✗ ({e})")
        issues.append("Encryption failed")

    # 3. NATS connection
    try:
        nc = await hive_connect(instance_id)
        print("   NATS connection: ✓")

        # 4. Pub/Sub
        received = []

        async def handler(msg):
            received.append(msg)

        await nc.subscribe("hive.healthcheck", cb=handler)
        data = make_envelope(instance_id, "healthcheck", "ping", key)
        await nc.publish("hive.healthcheck", data)
        await nc.flush()
        await asyncio.sleep(0.5)

        if received:
            print("   Pub/Sub: ✓")
        else:
            print("   Pub/Sub: ✗")
            issues.append("Pub/Sub failed")

        # 5. JetStream
        try:
            js = nc.jetstream()
            ai = await js.account_info()
            print(f"   JetStream: ✓ (streams: {ai.streams}, consumers: {ai.consumers}, storage: {ai.storage} bytes)")
        except Exception as e:
            print(f"   JetStream: ✗ ({e})")
            issues.append("JetStream unavailable")

        await nc.close()
    except Exception as e:
        print(f"   NATS connection: ✗ ({e})")
        issues.append("NATS connection failed")

    # 6. Presence freshness
    presence = _get_presence()
    now = int(time.time())
    for inst in HIVE_CONFIG["instances"]:
        last = presence.get(inst)
        if last and (now - last) < 600:
            print(f"   {inst}: ✓ (seen {now - last}s ago)")
        elif last:
            print(f"   {inst}: ⚠ (seen {(now - last) // 60}m ago)")
        else:
            print(f"   {inst}: ? (never seen)")

    # Summary
    if not issues:
        print("\n   Status: OPERATIONAL ✓")
    else:
        print(f"\n   Status: DEGRADED ✗ — {', '.join(issues)}")


async def cmd_test(args):
    """Test connectivity and encryption."""
    instance_id = get_instance_id()
    key = get_key()
    info = HIVE_CONFIG["instances"][instance_id]

    print(f"Instance: {info['emoji']} {instance_id} ({info['role']})")
    print(f"Server: {_get_server()}")
    print(f"Tunnel: {'yes' if _use_tunnel() else 'no'}")

    test_msg = "The Hive is alive."
    encrypted = encrypt(test_msg, key)
    decrypted = decrypt(encrypted, key)
    assert decrypted == test_msg, "Encryption roundtrip failed!"
    print(f"Encryption: ✓ (key loaded, roundtrip OK)")

    try:
        nc = await hive_connect(instance_id)
        print(f"NATS connection: ✓ (connected)")

        received = []

        async def handler(msg):
            received.append(msg)

        await nc.subscribe("hive.test", cb=handler)
        data = make_envelope(instance_id, "test", "ping", key)
        await nc.publish("hive.test", data)
        await nc.flush()
        await asyncio.sleep(0.5)
        await nc.close()

        if received:
            env = open_envelope(received[0].data, key)
            print(f"Pub/Sub: ✓ (sent and received: '{env['payload']}')")
        else:
            print("Pub/Sub: ✗ (published but not received)")

    except Exception as e:
        print(f"NATS connection: ✗ ({e})")

    print("\nHive status: OPERATIONAL ✓" if decrypted == test_msg else "\nHive status: DEGRADED ✗")


# --- Main ---

def main():
    parser = argparse.ArgumentParser(description="The Hive v2 — encrypted inter-instance communication")
    sub = parser.add_subparsers(dest="command")

    # send
    p_send = sub.add_parser("send", help="Send encrypted message")
    p_send.add_argument("channel", choices=HIVE_CONFIG["channels"] + ["dm.alpha", "dm.beta", "dm.gamma"])
    p_send.add_argument("message", nargs="+")
    p_send.add_argument("--reply-to", dest="reply_to", help="Message ID to reply to")
    p_send.add_argument("--urgent", action="store_true", help="Mark as urgent")
    p_send.add_argument("--type", dest="content_type", choices=list(MESSAGE_TYPES.keys()),
                        default=None, help="H17: structured message type (default: text)")
    p_send.add_argument("--force", action="store_true", help="H27: bypass dedup check")

    # send-structured (H17)
    p_ss = sub.add_parser("send-structured", help="Send structured message (H17)")
    p_ss.add_argument("channel", choices=HIVE_CONFIG["channels"] + ["dm.alpha", "dm.beta", "dm.gamma"])
    p_ss.add_argument("content_type", choices=list(MESSAGE_TYPES.keys()),
                       help="Structured message type")
    p_ss.add_argument("fields_json", help="JSON object with fields for the type")
    p_ss.add_argument("--reply-to", dest="reply_to", help="Message ID to reply to")
    p_ss.add_argument("--urgent", action="store_true", help="Mark as urgent")

    # types (list available message types)
    sub.add_parser("types", help="List available structured message types (H17)")

    # listen
    p_listen = sub.add_parser("listen", help="Listen for messages")
    p_listen.add_argument("channel", nargs="?", default=None)

    # check (with filters)
    p_check = sub.add_parser("check", help="Check for new persistent messages")
    p_check.add_argument("--skip-presence", dest="skip_presence", action="store_true",
                         help="(deprecated, now default) Hide presence heartbeat messages")
    p_check.add_argument("--include-presence", dest="include_presence", action="store_true",
                         help="Show presence heartbeat messages (hidden by default)")
    p_check.add_argument("--all", dest="show_all", action="store_true",
                         help="Show all messages including presence and system")
    p_check.add_argument("--channel", dest="channel", default=None,
                         help="Show only messages from this channel")
    p_check.add_argument("--urgent-only", dest="urgent_only", action="store_true",
                         help="Show only urgent messages")

    # history
    p_history = sub.add_parser("history", help="Browse message history")
    p_history.add_argument("channel", nargs="?", default=None, help="Filter by channel")
    p_history.add_argument("--hours", type=int, default=24, help="Hours to look back (default: 24)")
    p_history.add_argument("--from", dest="from_instance", default=None, help="Filter by sender instance")
    p_history.add_argument("--search", default=None, help="Search text in messages")

    # thread
    p_thread = sub.add_parser("thread", help="Show full reply chain for a message")
    p_thread.add_argument("msg_id", help="Message ID to trace thread from")

    # presence (with rich status)
    p_presence = sub.add_parser("presence", help="Announce presence")
    p_presence.add_argument("--status", dest="status_text", default=None,
                            help="Current status (e.g. busy, available, building)")
    p_presence.add_argument("--work", dest="work_text", default=None,
                            help="What you're working on")

    # pulse (H26)
    p_pulse = sub.add_parser("pulse", help="Send structured heartbeat pulse (H26)")
    p_pulse.add_argument("--status", dest="status_text", default=None,
                         help="Current status (e.g. alive, building, thinking)")
    p_pulse.add_argument("--work", dest="work_text", default=None,
                         help="What you're working on")
    p_pulse.add_argument("--force", action="store_true",
                         help="H27: bypass pulse rate limit")

    # who
    sub.add_parser("who", help="Check who's online (rich presence)")

    # test
    sub.add_parser("test", help="Test connectivity")

    # backfill (H16)
    p_backfill = sub.add_parser("backfill", help="Backfill local history from JetStream (H16)")
    p_backfill.add_argument("--channel", default=None, help="Specific channel to backfill")
    p_backfill.add_argument("--max", dest="max_count", type=int, default=500,
                            help="Max messages to replay (default: 500)")

    # health
    sub.add_parser("health", help="Full system health check")

    # share
    p_share = sub.add_parser("share", help="Share a file (< 100KB)")
    p_share.add_argument("file", help="Path to file")
    p_share.add_argument("channel", nargs="?", default="sync", help="Channel (default: sync)")

    # task
    p_task = sub.add_parser("task", help="Manage structured tasks")
    task_sub = p_task.add_subparsers(dest="task_action")

    p_assign = task_sub.add_parser("assign", help="Assign a task")
    p_assign.add_argument("assignee", choices=list(HIVE_CONFIG["instances"].keys()))
    p_assign.add_argument("description", nargs="+")
    p_assign.add_argument("--eta", help="Estimated time (e.g. '2h', '30m')")

    task_sub.add_parser("list", help="List tasks")

    p_done = task_sub.add_parser("done", help="Mark task complete")
    p_done.add_argument("task_id", help="Task ID to mark done")

    args = parser.parse_args()

    if args.command == "send":
        args.message = " ".join(args.message)
        asyncio.run(cmd_send(args))
    elif args.command == "send-structured":
        asyncio.run(cmd_send_structured(args))
    elif args.command == "types":
        print("📦 Hive Message Types (H17):")
        for name, info in MESSAGE_TYPES.items():
            fields = ", ".join(info["fields"]) if info["fields"] else "(plain text)"
            print(f"  {info['icon']} {name}: {info['desc']}")
            print(f"     Fields: {fields}")
    elif args.command == "listen":
        asyncio.run(cmd_listen(args))
    elif args.command == "check":
        asyncio.run(cmd_check(args))
    elif args.command == "history":
        asyncio.run(cmd_history(args))
    elif args.command == "thread":
        asyncio.run(cmd_thread(args))
    elif args.command == "presence":
        asyncio.run(cmd_presence(args))
    elif args.command == "pulse":
        asyncio.run(cmd_pulse(args))
    elif args.command == "who":
        asyncio.run(cmd_who(args))
    elif args.command == "test":
        asyncio.run(cmd_test(args))
    elif args.command == "backfill":
        asyncio.run(cmd_backfill(args))
    elif args.command == "health":
        asyncio.run(cmd_health(args))
    elif args.command == "share":
        asyncio.run(cmd_share(args))
    elif args.command == "task":
        if hasattr(args, "task_action") and args.task_action:
            asyncio.run(cmd_task(args))
        else:
            p_task.print_help()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
